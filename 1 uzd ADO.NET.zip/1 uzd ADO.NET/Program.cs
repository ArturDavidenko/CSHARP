﻿using System;
using System.Data;
using System.Data.OleDb;

namespace _1_uzd_ADO.NET
{
    class Program
    {
        private const string ConnString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source= text.xlsx; Extended Properties='Excel 12.0 xml;HDR=YES;'";

        static void Main(string[] args)
        {

            const string connString = ConnString;
            const string queryString = "SELECT * FROM [Sheet1$]";

            var connection = new OleDbConnection(connString);

            try
            {
                connection.Open();
                var cmd = new OleDbCommand(queryString, connection);
                var adapter = new OleDbDataAdapter {SelectCommand = cmd};
                var ds = new DataSet();

                adapter.Fill(ds, "Info");

                foreach (var m in ds.Tables[0].DefaultView)
                {
                    Console.WriteLine(((DataRowView)m).Row.ItemArray[0] + " " +
                        ((DataRowView)m).Row.ItemArray[1] + " " +
                        ((DataRowView)m).Row.ItemArray[2] + " " +
                        ((DataRowView)m).Row.ItemArray[3] + " " +
                        ((DataRowView)m).Row.ItemArray[4] + " " +
                        ((DataRowView)m).Row.ItemArray[5] + " " +
                        ((DataRowView)m).Row.ItemArray[6] + " " +
                        ((DataRowView)m).Row.ItemArray[7] + " " +
                        ((DataRowView)m).Row.ItemArray[8] + " " +
                        ((DataRowView)m).Row.ItemArray[9]);

                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error :" + e.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}
