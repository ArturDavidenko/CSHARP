﻿using Npgsql;
using System;

namespace _3_uzd
{
    class Program
    {
        static void Main(string[] args)
        {

            string connStr = "Host=localhost;Username=system;Database=csharp";
            NpgsqlConnection conn = new NpgsqlConnection(connStr);

            bool endWork = true;

            while (endWork)
            {
                Console.WriteLine("Choose your steps: ");
                Console.WriteLine("1 - read data");
                Console.WriteLine("2 - insert data");
                Console.WriteLine("3 - update data");
                Console.WriteLine("4 - delete data");
                Console.WriteLine("5 - end work");

                string choose = Console.ReadLine();

                NpgsqlTransaction transaction;

                switch (choose)
                {
                    case "1":
                        conn.Open();

                        string sql = "SELECT * from dators";
                        NpgsqlCommand readsql = new NpgsqlCommand(sql, conn);

                        var rdr = readsql.ExecuteReader();

                        Console.WriteLine($"{rdr.GetName(0)}"
                            + $"{rdr.GetName(1)}"
                            + $"{rdr.GetName(2)}" 
                            + $"{rdr.GetName(3)}" 
                            + $"{rdr.GetName(4)}"
                            + $"{rdr.GetName(5)}");

                        while (rdr.Read())
                        {
                            Console.WriteLine($"{rdr.GetInt32(0)}"
                                + $"{rdr.GetString(1)}"
                                + $"{rdr.GetString(2)}"
                                + $"{rdr.GetInt32(3)}"
                                + $"{rdr.GetInt32(4)}"
                                + $"{rdr.GetBoolean(5)}");
                        }

                        conn.Close();
                        Console.ReadLine();
                        Console.Clear();
                        break;


                    case "2":
                        Console.Write("Enter title: ");
                        var title = Console.ReadLine();
                        Console.Write("Enter manufacturer: ");
                        var manufacturer = Console.ReadLine();
                        Console.Write("Enter processor: ");
                        var processor = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter disk: ");
                        var disk = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Enter screen (y/n): ");
                        string screenDto = Console.ReadLine();
                        bool screen;
                        if (screenDto == "y")
                        {
                            screen = true;
                        }
                        else
                        {
                            screen = false;
                        }
                        conn.Open();

                        transaction = conn.BeginTransaction();

                        NpgsqlCommand insertSQL = new NpgsqlCommand( "INSTER INTO dators (title, manufacturer, cpu, disk, monitor) VALUES ('" + title + "' , "
                            + "'" + manufacturer + ", " + processor + ", " + disk + ", " + screen + ")", conn, transaction);


                        try
                        {
                            insertSQL.ExecuteNonQuery();
                            transaction.Commit();
                            conn.Close();
                            Console.WriteLine("Insert was successful!");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        catch (Exception e)
                        {
                            transaction.Rollback();
                            conn.Close();
                            Console.WriteLine(e.Message);
                            throw;
                        }
                        break;

                    case "3":
                        Console.Write("Enter computer id to update: ");
                        int computerIdToUpdate = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Updated title: ");
                        string updatedTitle = Console.ReadLine();
                        Console.Write("Updated manufacturer: ");
                        string updatedManufacturer = Console.ReadLine();
                        Console.Write("Updated processor count: ");
                        int updatedProcessorCount = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Updated hdd capacity: ");
                        int updatedDiskCapacity = Convert.ToInt32(Console.ReadLine());
                        Console.Write("Updated screen presence(y/n): ");
                        string updatedScreenPresenece = Console.ReadLine();
                        bool updatedScreen;
                        if (updatedScreenPresenece == "y")
                        {
                            updatedScreen = true;
                        }
                        else
                        {
                            updatedScreen = false;
                        }

                        conn.Open();

                        transaction = conn.BeginTransaction();

                        NpgsqlCommand updateSQL = new NpgsqlCommand("UPDATE dators SET title = '" + updatedTitle + "', razotajs = '" + updatedManufacturer +
                            "', procesors = " + updatedProcessorCount + ", cietais_disks = " + updatedDiskCapacity +
                            ", monitors = " + updatedScreen + " WHERE Id = " + computerIdToUpdate + "", conn, transaction);


                        try
                        {
                            updateSQL.ExecuteNonQuery();
                            transaction.Commit();
                            conn.Close();
                            Console.WriteLine($"Computer with id { computerIdToUpdate } successfully updated!");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        catch (Exception e)
                        {
                            transaction.Rollback();
                            conn.Close();
                            Console.WriteLine(e.Message);
                            Console.ReadLine();
                            Console.Clear();
                            throw;
                        }
                        break;
                    case "4":
                        Console.WriteLine("Choose id who deleted: ");
                        int computerToDelete = Convert.ToInt32(Console.ReadLine());

                        conn.Open();
                        transaction = conn.BeginTransaction();
                        NpgsqlCommand deleteSQL = new NpgsqlCommand("DELETE FROM dators where id = " + computerToDelete + "", conn, transaction);

                        try
                        {
                            deleteSQL.ExecuteNonQuery();
                            transaction.Commit();
                            conn.Close();
                            Console.WriteLine($"Computer with id { computerToDelete } successfully removed.");
                            Console.ReadLine();
                            Console.Clear();
                        }
                        catch (Exception e)
                        {
                            transaction.Rollback();
                            conn.Close();
                            Console.WriteLine(e.Message);
                            Console.ReadLine();
                            Console.Clear();
                            throw;
                        }
                        break;

                    case "5":
                        Console.WriteLine("End work!");
                        endWork = false;
                        break;
                    default:
                        Console.WriteLine("Not this choosen! ");
                        break;
                }
            }
        }
    }
}
