﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Data;
using System.Linq;

namespace _5_uzd
{
    class Program
    {

        const string cs = "Host=localhost;Username=Arturs;Database=csharp";
        static NpgsqlConnection con = new NpgsqlConnection(cs);

        private static DataTable dt = new DataTable();

        static void Main(string[] args)
        {
            var endWork = true;

            dt.Columns.Add(new DataColumn("id", typeof(int)));
            dt.Columns.Add(new DataColumn("name", typeof(string)));
            dt.Columns.Add(new DataColumn("isStudent", typeof(bool)));


            while (endWork)
            {
                Console.WriteLine("Choose ur step: ");
                Console.WriteLine("1 - Get data from DB");
                Console.WriteLine("2 - Insert data");
                Console.WriteLine("3 - Update data");
                Console.WriteLine("4 - Remove user data");
                Console.WriteLine("5 - Save changes");
                Console.WriteLine("6 - Exit");
                Console.WriteLine("Your choose: ");

                int choose = Convert.ToInt32(Console.ReadLine());

                switch (choose)
                {
                    case 1:
                        GetData();
                        break;
                    case 2:
                        InsertData();
                        break;
                    case 3:
                        UpdateData();
                        break;
                    case 4:
                        DeleteData();
                        break;
                    case 5:
                        SaveChanges();
                        break;
                    case 6:
                        Console.WriteLine("GoodBye!");
                        endWork = false;
                        break;
                    default:
                        Console.WriteLine("not this option!");
                        break;
                }
            }


        }


        private static void PrintTable(DataTable dataTable)
        {
            foreach (DataColumn dc in dataTable.Columns)
            {
                Console.Write(dc.ColumnName + "\t");
            }
            Console.WriteLine();
            Console.WriteLine();
            foreach (DataRow dr in dataTable.Rows)
            {
                if (dr.RowState != DataRowState.Deleted)
                {
                    for (int i = 0; i < dr.ItemArray.Length; i++)
                    {
                        Console.Write(dr[i] + "\t");
                    }
                    Console.WriteLine();
                }
            }
        }


        private static void GetData()
        {
            dt.Clear();
            NpgsqlCommand getData = new NpgsqlCommand("SELECT * FROM users", con);
            con.Open();
            NpgsqlDataReader dataReader = getData.ExecuteReader();

            while (dataReader.Read())
            {
                var dr = dt.NewRow();

                dr["id"] = dataReader["id"];
                dr["name"] = dataReader["name"];
                dr["isStudent"] = dataReader["isStudent"];

                dt.Rows.Add(dr);
            }

            con.Close();
            dt.AcceptChanges();
            PrintTable(dt);
        }

        private static void InsertData()
        {
            Console.WriteLine("How many rows u want to enter?: ");
            int rowsEnter = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < rowsEnter; i++)
            {
                var dr = dt.NewRow();

                var lastRow = dt.Rows[^1];
                var lastId = Convert.ToInt32(lastRow["id"]);
                var nextId = lastId + 1;

                dr["id"] = nextId.ToString();

                Console.Write("Enter name: ");
                dr["name"] = Console.ReadLine();

                Console.Write("This user is student? (y/n): ");
                var isStudentInput = Console.ReadLine();
                if (isStudentInput == "y")
                {
                    dr["isStudent"] = true;
                }
                else
                {
                    dr["isStudent"] = false;
                }
                ConfirmetInformation(dr);
                Console.WriteLine();
            }
            PrintTable(dt);
        }

        private static void UpdateData()
        {
            Console.Write("Enter user id: ");
            var userIdToUpdate = Console.ReadLine();

            var userToUpdate = dt.Select($"id = {userIdToUpdate}").FirstOrDefault();
            var i = 0;

            if (ConfirmetInformation() && userIdToUpdate != null)
            {
                foreach (var dataRow in dt.Rows){
                    if (userToUpdate == dataRow)
                    {
                        Console.WriteLine("Insert new name: ");
                        dt.Rows[i]["name"] = Console.ReadLine()!;

                        Console.Write("This user is still a student? (y/n): ");
                        var isStudentInput = Console.ReadLine()!;
                        if (isStudentInput == "y")
                        {
                            dt.Rows[i]["isStudent"] = true;
                        }
                        else
                        {
                           dt.Rows[i]["isStudent"] = false;
                        }
                    }
                    i++;
                }
            }
            else
            {
                Console.WriteLine($"No user with id {userIdToUpdate} is found.");
            }
        }


        private static void DeleteData()
        {
            Console.Write("Enter user id to delete: ");
            var userIdToDelete = Console.ReadLine();
            var userToDelete = dt.Select($"id = {userIdToDelete}").FirstOrDefault();

            if (ConfirmetInformation() && userToDelete != null)
            {
                foreach (DataRow dataRow in dt.Rows)
                {
                    if (dataRow.RowState != DataRowState.Deleted)
                    {
                        if (dataRow == userToDelete)
                        {
                            dataRow.Delete();
                        }
                    }
                }
                PrintTable(dt);
            }
            else
            {
                Console.WriteLine("Operation cancelled.");
            }
        }

        private static void SaveChanges()
        {
            var insertCommand = new NpgsqlCommand("INSERT INTO Users (name, isStudent) VALUES (@name, @isStudent)", con);
            insertCommand.Parameters.Add(new NpgsqlParameter("@name", NpgsqlDbType.Varchar));
            insertCommand.Parameters.Add(new NpgsqlParameter("@isStudent", NpgsqlDbType.Boolean));

            var updateCommand =
                new NpgsqlCommand(
                    "UPDATE Users SET name = @name, isStudent = @isStudent WHERE id = @id",
                    con);
            updateCommand.Parameters.Add(new NpgsqlParameter("@name", NpgsqlDbType.Varchar));
            updateCommand.Parameters.Add(new NpgsqlParameter("@isStudent", NpgsqlDbType.Boolean));

            var deleteCommand = new NpgsqlCommand("DELETE FROM Users WHERE id=@id", con);
            deleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer));

            foreach (var dataRow in dt.Rows.Cast<DataRow>().ToList())
            {
                if (dataRow.RowState == DataRowState.Added)
                {
                    insertCommand.Parameters[0].Value = dataRow[1];
                    insertCommand.Parameters[1].Value = dataRow[2];

                    con.Open();
                    insertCommand.ExecuteNonQuery();
                    con.Close();
                }

                if (dataRow.RowState == DataRowState.Modified)
                {
                    updateCommand.Parameters[0].Value = dataRow[0];
                    updateCommand.Parameters[1].Value = dataRow[1];

                    con.Open();
                    updateCommand.ExecuteNonQuery();
                    con.Close();
                }

                if (dataRow.RowState == DataRowState.Deleted)
                {
                    deleteCommand.Parameters[0].Value = dataRow[0, DataRowVersion.Original];

                    con.Open();
                    deleteCommand.ExecuteNonQuery();
                    con.Close();
                }
            }
            dt.AcceptChanges();
        }

        private static bool ConfirmetInformation()
        {
            Console.Write("Are you sure you want to proceed with operation? (y/n): ");
            var dialog = Console.ReadLine()!;
            if (dialog == "y")
            {
                return true;
            }

            Console.WriteLine("Operation cancelled.");
            return false;
        }


        private static void ConfirmetInformation(DataRow dr)
        {
            Console.WriteLine("Are you sure you want to add this data? (y/n): ");
            var dialog = Console.ReadLine()!;
            if (dialog == "y")
            {
                dt.Rows.Add(dr);
            }
            else
            {
                Console.WriteLine("Insertion cancelled.");
            }
        }
    }
}
