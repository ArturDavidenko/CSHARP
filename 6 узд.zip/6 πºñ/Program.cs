﻿using Npgsql;
using System;
using System.Data;
using System.Linq;

namespace _6_узд
{
    class Program
    {
        const string cs = "Host=localhost;Username=arturs;Database=csharp";
        private static readonly NpgsqlConnection Con = new NpgsqlConnection(cs);

        private static readonly DataTable Dt = new DataTable();
        private readonly NpgsqlDataAdapter _adapter = new NpgsqlDataAdapter();

        static void Main(string[] args)
        {
            Program pr = new Program();
            bool endWork = true;

            Dt.Columns.Add(new DataColumn("id", typeof(int)));
            Dt.Columns.Add(new DataColumn("title", typeof(string)));
            Dt.Columns.Add(new DataColumn("weight", typeof(int)));
            Dt.Columns.Add(new DataColumn("seats", typeof(int)));
            Dt.Columns.Add(new DataColumn("make", typeof(string)));
            Dt.Columns.Add(new DataColumn("model", typeof(int)));

            while (endWork)
            {
                Console.WriteLine("Choose operation");
                Console.WriteLine("1 - Get data from database.");
                Console.WriteLine("2 - Insert data.");
                Console.WriteLine("3 - Update data.");
                Console.WriteLine("4 - Remove user data.");
                Console.WriteLine("5 - Save changes.");
                Console.WriteLine("6 - Exit");
                Console.Write("Your choose: ");

                int choose = Convert.ToInt32(Console.ReadLine());

                switch (choose)
                {

                    case 1:
                        pr.GetData();
                        break;
                    case 2:
                        InsertData();
                        break;
                    case 3:
                        UpdateData();
                        break;
                    case 4:
                        DeleteData();
                        break;
                    case 5:
                        pr.SaveChanges();
                        break;
                    case 6:
                        Console.WriteLine("BYE !");
                        endWork = false;
                        break;
                    default:
                        Console.WriteLine("not this option!");
                        break;
                }
            }
        }

        private static bool ConfirmationDialog()
        {
            Console.Write("Are you sure you want to proceed with operation? (y/n): ");
            string dialog = Console.ReadLine();
            if (dialog == "y")
            {
                return true;
            }

            Console.WriteLine("Operation cancelled.");
            return false;
        }

        private static void ConfirmationDialog(DataRow dr)
        {
            Console.WriteLine("Are you sure you want to add this data? (y/n): ");
            string dialog = Console.ReadLine();
            if (dialog == "y")
            {
                Dt.Rows.Add(dr);
            }
            else
            {
                Console.WriteLine("Insertion cancelled.");
            }
        }

        private static void PrintDataTable(DataTable dataTable)
        {
            foreach (DataColumn dc in dataTable.Columns)
            {
                Console.Write($"|{dc.ToString().PadRight(10),12}|");
            }
            Console.WriteLine();


            foreach (DataRow dr in dataTable.Rows)
            {
                if (dr.RowState != DataRowState.Deleted)
                {
                    for (int i = 0; i < dr.ItemArray.Length; i++)
                    {
                        Console.Write($"|{dr[i].ToString()?.PadRight(10),12}|");
                    }
                    Console.WriteLine();
                }
            }
        }

        private void GetData()
        {
            Dt.Clear();
            NpgsqlCommand fetchData = new NpgsqlCommand("SELECT * FROM cars", Con);
            _adapter.SelectCommand = fetchData;
            _adapter.Fill(Dt);
            PrintDataTable(Dt);
        }

        private static void InsertData()
        {

            var dr = Dt.NewRow();

            var lastRow = Dt.Rows[^1];

            var lastId = Convert.ToInt32(lastRow["id"]);
            var nextId = lastId + 1;

            dr["id"] = nextId.ToString();

            Console.Write("Enter car title: ");
            dr["title"] = Console.ReadLine();

            Console.Write("Enter car weight: ");
            dr["weight"] = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter car seat count: ");
            dr["seats"] = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter car make(manufacturer): ");
            dr["make"] = Console.ReadLine();

            Console.Write("Enter car model: ");
            dr["model"] = Convert.ToInt32(Console.ReadLine());

            ConfirmationDialog(dr);
            Console.WriteLine();

            PrintDataTable(Dt);
        }


        private static void UpdateData()
        {
            Console.Write("Enter car id: ");
            var carIdToUpdate = Console.ReadLine();

            var carToUpdate = Dt.Select($"id = {carIdToUpdate}").FirstOrDefault();

            if (carIdToUpdate != null && ConfirmationDialog())
            {
                Console.Write("Enter car title: ");
                carToUpdate["title"] = Console.ReadLine();

                Console.Write("Enter car weight: ");
                carToUpdate["weight"] = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter car seat count: ");
                carToUpdate["seats"] = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter car make(manufacturer): ");
                carToUpdate["make"] = Console.ReadLine();

                Console.Write("Enter car model: ");
                carToUpdate["model"] = Convert.ToInt32(Console.ReadLine());
            }
            else
            {
                Console.WriteLine($"No car with id {carIdToUpdate} is found.");
            }

            PrintDataTable(Dt);
        }

        private static void DeleteData()
        {
            Console.Write("Enter user id to delete: ");
            var userIdToDelete = Console.ReadLine();
            var userToDelete = Dt.Select($"id = {userIdToDelete}").FirstOrDefault();

            if (ConfirmationDialog() && userToDelete != null)
            {
                foreach (DataRow dataRow in Dt.Rows)
                {
                    if (dataRow.RowState != DataRowState.Deleted)
                    {
                        if (dataRow == userToDelete)
                        {
                            dataRow.Delete();
                        }
                    }
                }
                PrintDataTable(Dt);
            }
            else
            {
                Console.WriteLine("Operation cancelled.");
            }
        }
        private void SaveChanges()
        {
            var insertCommand = new NpgsqlCommand("INSERT INTO Cars (title, weight, seats, make, model) VALUES (@title, @weight, @seats, @make, @model)", Con);
            insertCommand.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));
            insertCommand.Parameters.Add(new NpgsqlParameter("@weight", NpgsqlDbType.Integer, 12, "weight"));
            insertCommand.Parameters.Add(new NpgsqlParameter("@seats", NpgsqlDbType.Integer, 12, "seats"));
            insertCommand.Parameters.Add(new NpgsqlParameter("@make", NpgsqlDbType.Varchar, 12, "make"));
            insertCommand.Parameters.Add(new NpgsqlParameter("@model", NpgsqlDbType.Integer, 12, "model"));

            var updateCommand =
                new NpgsqlCommand(
                    "UPDATE Cars SET title = @title, weight = @weight, seats = @seats, make = @make, model = @model WHERE id = @id",
                    Con);
            updateCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            updateCommand.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));
            updateCommand.Parameters.Add(new NpgsqlParameter("@weight", NpgsqlDbType.Integer, 12, "weight"));
            updateCommand.Parameters.Add(new NpgsqlParameter("@seats", NpgsqlDbType.Integer, 12, "seats"));
            updateCommand.Parameters.Add(new NpgsqlParameter("@make", NpgsqlDbType.Varchar, 12, "make"));
            updateCommand.Parameters.Add(new NpgsqlParameter("@model", NpgsqlDbType.Integer, 12, "model"));

            var deleteCommand = new NpgsqlCommand("DELETE FROM Cars WHERE id=@id", Con);
            deleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            _adapter.InsertCommand = insertCommand;
            _adapter.UpdateCommand = updateCommand;
            _adapter.DeleteCommand = deleteCommand;

            _adapter.Update(Dt);
            Console.WriteLine("Database is updated.");
        }
    

    }
}
