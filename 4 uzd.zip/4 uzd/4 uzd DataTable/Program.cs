﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace _4_uzd_DataTable
{
    class Program
    {
        const string connStr = "Server=(localdb)\\mssqllocaldb; Database=csharp; Trusted_Connection=True; MultipleActiveResultSets=True;";
        static SqlConnection connection = new SqlConnection(connStr);
        private static DataTable dt = new DataTable();

        static void Main(string[] args)
        {
            bool endWork = true;

            dt.Columns.Add(new DataColumn("id", typeof(int)));
            dt.Columns.Add(new DataColumn("name", typeof(string)));
            dt.Columns.Add(new DataColumn("surname", typeof(string)));
            dt.Columns.Add(new DataColumn("age", typeof(int)));
            dt.Columns.Add(new DataColumn("status", typeof(bool)));


            while (endWork)
            {
                Console.WriteLine("Choose step: ");
                Console.WriteLine("1 - Get data from DB");
                Console.WriteLine("2 - Add data to DB");
                Console.WriteLine("3 - Update data to DB");
                Console.WriteLine("4 - Delete user data from DB");
                Console.WriteLine("5 - Save changes");
                Console.WriteLine("6 - Exit");

                int choose = Convert.ToInt32(Console.ReadLine());

                switch (choose)
                {
                    case 1:
                        GetData();
                        break;
                    case 2:
                        AddData();
                        break;
                    case 3:
                        UpdateData();
                        break;
                    case 4:
                        DeleteData();
                        break;
                    case 5:
                        SaveChanges();
                        break;
                    case 6:
                        Console.WriteLine("End work!");
                        endWork = false;
                        break;
                    default:
                        Console.WriteLine("Not found that step!");
                        break;
                }

            }
        }

        private static void GetData()
        {
            dt.Clear();
            var getData = new SqlCommand("SELECT * FROM Users", connection);
            connection.Open();
            var dataReader = getData.ExecuteReader();
            while (dataReader.Read())
            {
                var dr = dt.NewRow();

                dr["id"] = dataReader["id"];
                dr["name"] = dataReader["name"];
                dr["srnm"] = dataReader["srnm"];
                dr["status"] = dataReader["status"];
                dr["infl"] = dataReader["infl"];
                dr["cars"] = dataReader["cars"];
                dr["childs"] = dataReader["childs"];
                dr["profession"] = dataReader["profession"];

                dt.Rows.Add(dr);
            }
            connection.Close();
            dt.AcceptChanges();
            PrintDataTable(dt);
        }


        private static void PrintDataTable(DataTable dataTable)
        {
            foreach (DataColumn dc in dataTable.Columns)
            {
                Console.Write(dc.ColumnName + "\t");
            }
            Console.WriteLine();
            Console.WriteLine();
            foreach (DataRow dr in dataTable.Rows)
            {
                if (dr.RowState != DataRowState.Deleted)
                {
                    for (int i = 0; i < dr.ItemArray.Length; i++)
                    {
                        Console.Write(dr[i] + "\t");
                    }
                    Console.WriteLine();
                }
            }
        }

        private static void AddData()
        {
            var dr = dt.NewRow();

            var lastRow = dt.Rows[dt.Rows.Count - 1];
            var lastId = Convert.ToInt32(lastRow["id"]);
            var nextId = lastId + 1;

            dr["id"] = nextId.ToString();

            Console.Write("Enter name: ");
            dr["name"] = Console.ReadLine();

            Console.Write("Enter surname: ");
            dr["surname"] = Console.ReadLine();

            Console.Write("Enter age: ");
            dr["age"] = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter status. Study ? y/n: ");
            string status = Console.ReadLine();

            if (status == "y")
            {
                dr["status"] = true;
            }
            else
            {
                dr["status"] = false;
            }

            ConfimInfo(dr);
        }

        private static void UpdateData()
        {
            Console.WriteLine("Enter user id: ");
            var userIdToUpdate = Console.ReadLine();

            var userToUpdate = dt.Select($"id = {userIdToUpdate}").FirstOrDefault();
            var i = 0;

            if (ConfimInfo() && userIdToUpdate != null)
            {
                foreach (var dataRow in dt.Rows)
                {
                    if (userToUpdate == dataRow)
                    {
                        Console.WriteLine("Enter new name: ");
                        dt.Rows[i]["name"] = Console.ReadLine();
                        Console.WriteLine("Enter new surname: ");
                        dt.Rows[i]["surname"] = Console.ReadLine();
                        Console.WriteLine("Enter new age: ");
                        dt.Rows[i]["age"] = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter new status: y/n ");
                        var status = Console.ReadLine();
                        if (status == "y")
                        {
                            dt.Rows[i]["status"] = true;
                        }
                        else
                        {
                            dt.Rows[i]["status"] = false;
                        }
                    }
                    i++;
                }
            }
            else
            {
                Console.WriteLine("No user with this id!");
            }
        }

        private static void DeleteData()
        {
            Console.WriteLine("Enter user id to delete: ");
            var userIdToDelete = Console.ReadLine();
            var userToDelete = dt.Select($"id = {userIdToDelete}").FirstOrDefault();

            if (ConfimInfo() && userIdToDelete != null)
            {
                foreach (DataRow dataRow in dt.Rows)
                {
                    if (dataRow.RowState != DataRowState.Deleted)
                    {
                        if (dataRow == userToDelete)
                        {
                            dataRow.Delete();
                        }
                    }
                }
            }
            
        }

        private static bool ConfimInfo()
        {
            Console.WriteLine("Are u sure to change datya in DB? (y/n): ");
            var cnf = Console.ReadLine();

            if (cnf == "y")
            {
                return true;
            }

            Console.WriteLine("Operation cancelled!");
            return false;
        }

        private static void ConfimInfo(DataRow dr)
        {
            Console.WriteLine("Are u sure to change datya in DB? (y/n): ");
            var cnf = Console.ReadLine();

            if (cnf == "y")
            {
                dt.Rows.Add(dr);
            }
            else
            {
                Console.WriteLine("Operation cancelled!");
            }
        }


        private static void SaveChanges()
        {
            var insertCommand = new SqlCommand("INSERT INTO Users (name, srnm, status, infl, cars, childs, profession) VALUES (@name, @srnm, @status, @infl, @cars, @childs, @profession)", connection);
            insertCommand.Parameters.Add(new SqlParameter("@name", SqlDbType.VarChar));
            insertCommand.Parameters.Add(new SqlParameter("@srnm", SqlDbType.VarChar));
            insertCommand.Parameters.Add(new SqlParameter("@status", SqlDbType.VarChar));
            insertCommand.Parameters.Add(new SqlParameter("@infl", SqlDbType.Bit));
            insertCommand.Parameters.Add(new SqlParameter("@cars", SqlDbType.Int));
            insertCommand.Parameters.Add(new SqlParameter("@childs", SqlDbType.Bit));
            insertCommand.Parameters.Add(new SqlParameter("@profession", SqlDbType.VarChar));

            var updateCommand =
                new SqlCommand(
                    "UPDATE Users SET name = @name, srnm = @srnm, status = @status, infl = @infl, cars = @cars, childs = @childs, profession = @profession WHERE id = @id",
                    connection);
            updateCommand.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));
            updateCommand.Parameters.Add(new SqlParameter("@name", SqlDbType.VarChar));
            updateCommand.Parameters.Add(new SqlParameter("@srnm", SqlDbType.VarChar));
            updateCommand.Parameters.Add(new SqlParameter("@status", SqlDbType.VarChar));
            updateCommand.Parameters.Add(new SqlParameter("@infl", SqlDbType.Bit));
            updateCommand.Parameters.Add(new SqlParameter("@cars", SqlDbType.Int));
            updateCommand.Parameters.Add(new SqlParameter("@childs", SqlDbType.Bit));
            updateCommand.Parameters.Add(new SqlParameter("@profession", SqlDbType.VarChar));

            var deleteCommand = new SqlCommand("DELETE FROM Users WHERE id=@id", connection);
            deleteCommand.Parameters.Add(new SqlParameter("@id", SqlDbType.Int));

            foreach (var dataRow in dt.Rows.Cast<DataRow>().ToList())
            {
                if (dataRow.RowState == DataRowState.Added)
                {
                    insertCommand.Parameters[0].Value = dataRow[1];
                    insertCommand.Parameters[1].Value = dataRow[2];
                    insertCommand.Parameters[2].Value = dataRow[3];
                    insertCommand.Parameters[3].Value = dataRow[4];
                    insertCommand.Parameters[4].Value = dataRow[5];
                    insertCommand.Parameters[5].Value = dataRow[6];
                    insertCommand.Parameters[6].Value = dataRow[7];

                    connection.Open();
                    insertCommand.ExecuteNonQuery();
                    connection.Close();
                }

                if (dataRow.RowState == DataRowState.Modified)
                {
                    updateCommand.Parameters[0].Value = dataRow[0];
                    updateCommand.Parameters[1].Value = dataRow[1];
                    updateCommand.Parameters[2].Value = dataRow[2];
                    updateCommand.Parameters[3].Value = dataRow[3];
                    updateCommand.Parameters[4].Value = dataRow[4];
                    updateCommand.Parameters[5].Value = dataRow[5];
                    updateCommand.Parameters[6].Value = dataRow[6];
                    updateCommand.Parameters[7].Value = dataRow[7];

                    connection.Open();
                    updateCommand.ExecuteNonQuery();
                    connection.Close();
                }

                if (dataRow.RowState == DataRowState.Deleted)
                {
                    deleteCommand.Parameters[0].Value = dataRow[0, DataRowVersion.Original];

                    connection.Open();
                    deleteCommand.ExecuteNonQuery();
                    connection.Close();
                }
            }
            dt.AcceptChanges();
        }
    }
}
