﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace _4_uzd_DataTable
{
    class Program
    {
        const string connStr = "Server=(localdb)\\mssqllocaldb; Database=csharp; Trusted_Connection=True; MultipleActiveResultSets=True;";
        static SqlConnection connection = new SqlConnection(connStr);
        private static DataTable dt = new DataTable();

        static void Main(string[] args)
        {
            bool endWork = true;

            dt.Columns.Add(new DataColumn("id", typeof(int)));
            dt.Columns.Add(new DataColumn("name", typeof(string)));
            dt.Columns.Add(new DataColumn("surname", typeof(string)));
            dt.Columns.Add(new DataColumn("age", typeof(int)));
            dt.Columns.Add(new DataColumn("status", typeof(bool)));


            while (endWork)
            {
                Console.WriteLine("Choose step: ");
                Console.WriteLine("1 - Add data to DB");
                Console.WriteLine("2 - Update data to DB");
                Console.WriteLine("3 - Delete user data from DB");
                Console.WriteLine("4 - Exit");

                int choose = Convert.ToInt32(Console.ReadLine());

                switch (choose)
                {
                    case 1:
                        AddData();
                        break;
                    case 2:
                        UpdateData();
                        break;
                    case 3:
                        DeleteData();
                        break;
                    case 4:
                        Console.WriteLine("End work!");
                        endWork = false;
                        break;
                    default:
                        Console.WriteLine("Not found that step!");
                        break;
                }

            }
        }

        private static void AddData()
        {
            var dr = dt.NewRow();

            var lastRow = dt.Rows[dt.Rows.Count - 1];
            var lastId = Convert.ToInt32(lastRow["id"]);
            var nextId = lastId + 1;

            dr["id"] = nextId.ToString();

            Console.Write("Enter name: ");
            dr["name"] = Console.ReadLine();

            Console.Write("Enter surname: ");
            dr["surname"] = Console.ReadLine();

            Console.Write("Enter age: ");
            dr["age"] = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter status. Study ? y/n: ");
            string status = Console.ReadLine();

            if (status == "y")
            {
                dr["status"] = true;
            }
            else
            {
                dr["status"] = false;
            }

            ConfimInfo(dr);
        }

        private static void UpdateData()
        {
            Console.WriteLine("Enter user id: ");
            var userIdToUpdate = Console.ReadLine();

            var userToUpdate = dt.Select($"id = {userIdToUpdate}").FirstOrDefault();
            var i = 0;

            if (ConfimInfo() && userIdToUpdate != null)
            {
                foreach (var dataRow in dt.Rows)
                {
                    if (userToUpdate == dataRow)
                    {
                        Console.WriteLine("Enter new name: ");
                        dt.Rows[i]["name"] = Console.ReadLine();
                        Console.WriteLine("Enter new surname: ");
                        dt.Rows[i]["surname"] = Console.ReadLine();
                        Console.WriteLine("Enter new age: ");
                        dt.Rows[i]["age"] = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("Enter new status: y/n ");
                        var status = Console.ReadLine();
                        if (status == "y")
                        {
                            dt.Rows[i]["status"] = true;
                        }
                        else
                        {
                            dt.Rows[i]["status"] = false;
                        }
                    }
                    i++;
                }
            }
            else
            {
                Console.WriteLine("No user with this id!");
            }
        }

        private static void DeleteData()
        {
            Console.WriteLine("Enter user id to delete: ");
            var userIdToDelete = Console.ReadLine();
            var userToDelete = dt.Select($"id = {userIdToDelete}").FirstOrDefault();

            if (ConfimInfo() && userIdToDelete != null)
            {
                foreach (DataRow dataRow in dt.Rows)
                {
                    if (dataRow.RowState != DataRowState.Deleted)
                    {
                        dataRow.Delete();
                    }
                }
            }
            
        }

        private static bool ConfimInfo()
        {
            Console.WriteLine("Are u sure to change datya in DB? (y/n): ");
            var cnf = Console.ReadLine();

            if (cnf == "y")
            {
                return true;
            }

            Console.WriteLine("Operation cancelled!");
            return false;
        }

        private static void ConfimInfo(DataRow dr)
        {
            Console.WriteLine("Are u sure to change datya in DB? (y/n): ");
            var cnf = Console.ReadLine();

            if (cnf == "y")
            {
                dt.Rows.Add(dr);
            }
            else
            {
                Console.WriteLine("Operation cancelled!");
            }
        }
    }
}
