﻿using System;
using System.Data.OleDb;

namespace v2_uzd_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string ConnString = @"Provider=Microsoft.ACE.OLEDB.12.0; Data Source= text2.xlsx; Extended Properties='Excel 12.0 xml;HDR=YES;'";
            string queryString = "SELECT * FROM [Sheet1$]";
            string queryString2 = "INSERT INTO Table1(Name, Lastname) VALUES(?,?)";
            string ConnString2 = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=\"text2.accdb\"";

            OleDbConnection connection = new OleDbConnection(ConnString);
            OleDbConnection connection2 = new OleDbConnection(ConnString2);

            try
            {
                OleDbCommand cmd = new OleDbCommand(queryString, connection);
                connection.Open();
                OleDbDataReader dataReader = cmd.ExecuteReader();
                dataReader.Read();

                while (dataReader.Read())
                {
                   Console.WriteLine(dataReader.GetValue(0));  
                }

                Console.WriteLine("Write amount of person: ");
                int AmountOfPerson = Convert.ToInt32(Console.ReadLine());
                string name;
                string lastname;

                for (int i = 0; i < AmountOfPerson; i++)
                {
                    OleDbCommand cmd2 = new OleDbCommand(queryString2, connection2);
                    Console.WriteLine("Write name: ");
                    name = Console.ReadLine();
                    Console.WriteLine("Write lastname");
                    lastname = Console.ReadLine();
                    cmd2.Parameters.AddWithValue("Name", name);
                    cmd2.Parameters.AddWithValue("Lastname", lastname);
                    connection2.Open();
                    cmd2.ExecuteNonQuery();
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Error :" + e.Message);
            }
            finally
            {
                connection2.Close();
                connection.Close();
            }




        }
    }
}
