﻿using System;

namespace _11_узд_3_даля
{
    class Program
    {
        class Constructor
        {
            public Constructor()
            {
                Console.WriteLine("Default Constructor");
            }
            public Constructor(int i)
            {
                Console.WriteLine($"int is {i}");
            }
            public Constructor(double d)
            {
                Console.WriteLine($"double is {d}");
            }
            public Constructor(string s)
            {
                Console.WriteLine($"string is {s}");
            }
        }

        static void Main(string[] args)
        {
            Constructor C1 = new Constructor();
            Constructor C2 = new Constructor(1);
            Constructor C3 = new Constructor(2.2);
            Constructor C4 = new Constructor("hello wrld!");
        }
    }
}
