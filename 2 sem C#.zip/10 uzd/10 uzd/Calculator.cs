﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _10_uzd
{
    class Calculator
    {
        public void Formula1(ref int x)
        {
            int result = (int)Math.Pow(x, Math.IEEERemainder(1, x));
            Console.WriteLine("ur result: " + result);
        }

        public void Formula2(ref int x, ref int y)
        {
            int result = x * y;
            Console.WriteLine("ur result: " + result);
        }


        //public void Formula()
        //{
        //  x = (int)Math.Pow(x, Math.IEEERemainder(1, x));
        //  Console.WriteLine(x);
        //} 
    }
}
