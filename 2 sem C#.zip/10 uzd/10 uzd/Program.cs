﻿using System;

namespace _10_uzd
{

    class Program
    {

        static void Main(string[] args)
        {

            int x, y;
            Calculator result1 = new Calculator();

            Console.Write("Write your x: ");
            int.TryParse(Console.ReadLine(), out x);
            Console.Write("Write your y: ");
            int.TryParse(Console.ReadLine(), out y);

            result1.Formula1(ref x);
            result1.Formula2(ref x, ref y);
        }

    }
}
