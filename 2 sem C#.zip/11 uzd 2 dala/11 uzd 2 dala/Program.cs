﻿using System;

namespace _11_uzd_2_dala
{
    class Program
    {
        class First
        {
            public First()
            {
                Console.WriteLine("First object is created");
            }
            ~First()
            {
                Console.WriteLine("First object destroyed");
            }
        }
        class Second : First
        {
            public Second()
            {
                Console.WriteLine("Second object is created");
            }
            ~Second()
            {
                Console.WriteLine("Second object destroyed");
            }
        }
        class Third : Second
        {
            public Third()
            {
                Console.WriteLine("Third object is created");
            }
            ~Third()
            {
                Console.WriteLine("Thrid object destroyed");
            }
        }
        static void Main(string[] args)
        {
            Third V3 = new Third();
        }
    }
}
