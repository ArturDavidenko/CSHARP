﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7_uzd
{
    class Point
    {
        public double x;
        public double y;
        public string color;


        public Point(double x, double y, string color)
        {
            this.x = x;
            this.y = y;
            this.color = color;
        }

        public void Register(double x, double y, string color)
        {
            this.x = x;
            this.y = y;
            this.color = color;
        }
        public void GetStringData()
        {
           Console.WriteLine($"ur x: {this.x} \t ur y: {this.y} \t ur colot: {this.color}");
        }

    }
}
