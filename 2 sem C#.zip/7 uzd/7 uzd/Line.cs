﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7_uzd
{
    class Line
    {
        public Point A;
        public Point B;
        public string color;


        public Line(Point A, Point B, string color)
        {
            this.A = A;
            this.B = B;
            this.color = color;
        }

        public Line(Point[] points, string color)
        {
            if (points.Length != 2)
            {
                throw new Exception("Array size mismatch");  
            }
            else
            {
                this.A = points[0];
                this.B = points[1];
                this.color = color;
            }
        }

        public double GetLength()
        { 
           double lens = Math.Sqrt(Math.Pow(B.x - A.y, 2));
           return lens; 
        }
    }
}
