﻿using System;

namespace _7_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            Point[] arr = new Point[2];
            
            arr[0] = new Point(2, 3, "blue");
            arr[1] = new Point(2, 5, "grey");

            for (int i = 0; i < arr.Length; i++)
            {
                arr[i].GetStringData();
            }

            Line b = new Line(arr, "green"); 

            Data c = new Data();
            c.Print(b);
        }
    }
}
