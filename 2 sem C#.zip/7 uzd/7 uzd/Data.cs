﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _7_uzd
{
    class Data
    {
      public void Print(Line l)
      {
         Console.WriteLine($"ur lenght is: {l.GetLength()},({l.A.x};{l.A.y}),({l.B.x};{l.B.y})");
      } 
    }
}
