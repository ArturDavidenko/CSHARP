﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _9_uzd
{

   public struct Employee
   {
        public int Id { get; set; } 
        public string Name { get; set; }
        public string Lastname { get; set; }
        public int NumberOfChildren { get; set; }
        public string Position { get; set; }
        public bool Load { get; set; }

        public Employee(int id, string name, string lastname, int numberOfChildren, string position, bool load)
        {
            Id = id;
            Name = name;
            Lastname = lastname;
            NumberOfChildren = numberOfChildren;
            Position = position;
            Load = load;
        }

   }


    class Program
    {
        public static List<Employee> EmployeeList = new List<Employee>();
        public static Employee Registration()
        {
            int Id;
            string Name;
            string Lastname;
            int NumberOfChildren;
            string Position;
            bool Load;

            Console.WriteLine("Id:");
            Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Name:");
            Name = Console.ReadLine();
            Console.WriteLine("Lastname:");
            Lastname = Console.ReadLine();
            Console.WriteLine("Numeric of children:");
            NumberOfChildren = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Positions:");
            Position = Console.ReadLine();
            Console.WriteLine("Load:");
            Load = Convert.ToBoolean(Console.ReadLine());

            return new Employee(Id, Name, Lastname, NumberOfChildren, Position, Load);
        }

        public static void Print()
        {
            foreach (var item in EmployeeList)
            {
                Console.WriteLine($"Id: {item.Id} \t Name: {item.Name} \t Lastname: {item.Lastname}\t Numeric of children: {item.NumberOfChildren} \t Position: {item.Position} \t Load: {item.Load}\t");
            }
        }

        public static void Print(int Id)
        {
            try
            {
                var item = EmployeeList.First(x => x.Id == Id);
                Console.WriteLine($"Id: {item.Id} \t Name: {item.Name} \t Lastname: {item.Lastname}\t Numeric of children: {item.NumberOfChildren} \t Position: {item.Position} \t Load: {item.Load}\t");
            }
            catch
            {
                Console.WriteLine("not found!");
            }
        }

        static void Main(string[] args)
        {

            bool IsEnd = false;

            do
            {
                Console.WriteLine("1 - Create employee");
                Console.WriteLine("2 - Show on screen");
                Console.WriteLine("3 - Looking for employee(use id)");
                Console.WriteLine("Choose your step: ");

                string choose = Console.ReadLine();

                switch (choose)
                {
                    case "1":
                        Employee employee = Registration();
                        EmployeeList.Add(employee);
                        break;

                    case "2":
                        Print();
                        break;

                    case "3":
                        Console.WriteLine("What is ur ID:");
                        int id = Convert.ToInt32(Console.ReadLine());
                        Print(id);
                        break;

                    default:
                        Console.WriteLine("Nothing found!");
                        IsEnd = true;
                        break;
                }
            }
            while (!IsEnd);
        }

    }
}



