﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;
using System.Linq;

namespace _8_uzd
{
    class Classmate
    {
        public string Name;
        public string Lastname;
        public string Id_Classmate;

        public void Regestration()
        {
            Console.WriteLine("Classmate name: ");
            Name = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Classmate lastname: ");
            Lastname = Convert.ToString(Console.ReadLine());
            Console.WriteLine("Classmate ID: ");
            Id_Classmate = Convert.ToString(Console.ReadLine());
        }

        public DateTime LookingForAge(string Id_Classmate)
        {
            Id_Classmate = new String(Id_Classmate.TakeWhile(Char.IsDigit).ToArray());
            DateTime BornDate;
            DateTime.TryParseExact(Id_Classmate, "ddMMyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out BornDate);
            DateTime Today = DateTime.Today;

            var SumOfToday = (Today.Year * 100 + Today.Month) * 100 + Today.Day;
            var SumOfBorndate = (BornDate.Year * 100 + BornDate.Month) * 100 + BornDate.Day;

            var ClassmateAge = (SumOfToday - SumOfBorndate) / 10000;

            Console.WriteLine($"Classmate Born day is: {BornDate.ToString("dd/MM/yyyy")}");
            Console.WriteLine($"Classmate age is: {ClassmateAge} year");
            return BornDate;
        }

        public void Print()
        {
            Console.WriteLine($"Classmate name: {Name}, lastname: {Lastname}, Id: {Id_Classmate}");
            LookingForAge(Id_Classmate);
        }

    }
}
