﻿using System;

namespace _8_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please reg ur class");
            Console.Write("How much classes: ");
            int ClassNum = Convert.ToInt32(Console.ReadLine());
            Class[] classes = new Class[ClassNum];

            for (int i = 0; i < ClassNum; i++)
            {
                classes[i] = new Class();
                Console.WriteLine($"{i + 1} class data");
                classes[i].Regestration();
            }

            bool EndWork = true;


            do
            {
                Console.Clear();
                Console.WriteLine("Choose ur step: ");
                Console.WriteLine("1 - looking for specific class");
                Console.WriteLine("2 - show info of classes");
                Console.WriteLine("3 - looking for specific classmate");
                Console.WriteLine("4 - looking for oldest classmate");
                Console.WriteLine("ur choose: ");

                string choose = Console.ReadLine();

                switch (choose)
                {
                    case "1":
                        LookingForSpecificClass();
                        endWork();
                        Console.Clear();
                        break;
                    case "2":
                        DateOfClase();
                        endWork();
                        Console.Clear();
                        break;
                    case "3":
                        SpecificClaseLookSpecificClassmate();
                        endWork();
                        Console.Clear();
                        break;
                    case "4":
                        LookinkForOldestClassmate();
                        endWork();
                        Console.Clear();
                        break;
                    default:
                        Console.WriteLine("No this choosel.");
                        break;
                }
            }
            while (EndWork != false);

               
            static Class LookingForClass(Class[] clases, string name)
            {
                int index = 0;
                bool classFound = false;
                if (classFound == true)
                {
                    for (int i = 0; i < clases.Length; i++)
                    {
                        if (clases[i].ClassName == name)
                        {
                            Console.WriteLine($"clase of name '{name}'.");
                            return clases[index];
                        }
                    }
                    return clases[index];
                }
                else
                {
                    Console.WriteLine("not looking for");
                    return clases[index];
                }
            }

            void LookingForSpecificClass()
            {
                Console.Clear();
                Console.WriteLine("Type ur lokking for class name: ");
                string name = Console.ReadLine();
                LookingForClass(classes, name);
            }

            bool endWork()
            {
                Console.WriteLine("do u want end work y/n");
                string chooseOfUser = Console.ReadLine();
                if (chooseOfUser == "y")
                {
                    return EndWork = true;
                }
                else if (chooseOfUser == "n")
                {
                    return EndWork = false;
                }
                else
                {
                    Console.WriteLine("not choosen");
                    return EndWork = true;
                }
            }

            void DateOfClase()
            {
                Console.Clear();
                foreach(var clase in classes)
                {
                    clase.Print();
                }
            }

            void SpecificClaseLookSpecificClassmate()
            {
                Console.WriteLine("Choose class where classmate: ");
                string ClassName = Console.ReadLine();
                Console.WriteLine("Type name of classmate or lastname: ");
                string classmateNameOrLastname = Console.ReadLine();
                LookingForClass(classes, ClassName).LookingForClassmate(classmateNameOrLastname);
            }

            void LookinkForOldestClassmate()
            {
                Console.WriteLine("Type class where classmate: ");
                string ClassName = Console.ReadLine();
                LookingForClass(classes, ClassName).OldestClassmate();
            }
        }
    }
}
