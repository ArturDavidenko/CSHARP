﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _8_uzd
{
    class Class
    {
        public string ClassName;
        public int ClassmatesNumber;

        Classmate[] classmates = new Classmate[2];
        Teacher educator = new Teacher();

        public void Regestration()
        {
            Console.WriteLine($"ClassName: {ClassName}");
            ClassName = Console.ReadLine();
            Console.WriteLine("Numbers of classmates: ");
            this.ClassmatesNumber = Convert.ToInt32(Console.ReadLine());
            educator.Regestration();


            Array.Resize<Classmate>(ref classmates, this.ClassmatesNumber);
            int ClassmatesNumber = 0;
            for (int i = 0; i < classmates.Length; i++)
            {
                Console.Clear();
                ClassmatesNumber++;
                Console.WriteLine($"{ClassmatesNumber} classmate data regestration: ");
                Classmate scoolman = new Classmate();
                scoolman.Regestration();
                classmates[i] = scoolman;
            }
        }

        public void Print()
        {
            Console.WriteLine($"Classname: {ClassName}, where studying {ClassmatesNumber} classmates.");
        }

        public void LookingForClassmate(string LookingForClassmates)
        {
            for (int i = 0; i < classmates.Length; i++)
            {
                if (classmates[i].Name == LookingForClassmates || classmates[i].Lastname == LookingForClassmates)
                {
                    classmates[i].Print();
                }
                else
                {
                    Console.WriteLine("Not looking for it");
                }
            }
        }


        public void OldestClassmate()
        {
            Classmate oldestClassmate = null;

            foreach (var classmate in classmates)
            {
                if (oldestClassmate == null || classmate.LookingForAge(classmate.Id_Classmate) < oldestClassmate.LookingForAge(oldestClassmate.Id_Classmate))
                {
                    oldestClassmate = classmate;
                }
            }
            Console.WriteLine($"Oldest one is: {oldestClassmate.Name} {oldestClassmate.Lastname}.");
        }


        public void PrintData()
        {
            foreach (var classmate in classmates)
            {
                Console.WriteLine($"Class is classmates with name: {classmate.Name} and lastname {classmate.Lastname}.");
            }
        } 
    }
}
