﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _8_uzd
{
    class Teacher
    {
        public string Name;
        public string Lastname;
        public double salary;

        public void Regestration()
        {
            Console.WriteLine("Teacher name: ");
            Name = Console.ReadLine();
            Console.WriteLine("Teacher lastname: ");
            Lastname = Console.ReadLine();
            Console.WriteLine("Teacher salary: ");
            salary = Convert.ToDouble(Console.ReadLine());
        }

        public void TaxesOfSalary(double salary)
        {
            double investments = 0.11;
            double taxes = 0.20;
            double SalaryWithTaxes = salary * (1 - (investments + taxes));
            Console.WriteLine($"Teacher salary with taxes: {SalaryWithTaxes}");
        }

        public void Print()
        {
            Console.WriteLine($"Teacher name: {Name}, lastname: {Lastname}, salary: {salary}");
            TaxesOfSalary(salary);
        }
    }
}
