﻿using System;
using System.Text;
using System.Security.Cryptography;

namespace _12_uzd
{
    public class myConsole
    {
        public static string tagad = Convert.ToString(DateTime.Now.ToShortDateString()); 
        // mainīgajam piešķirt patreizējo datumu. Formātu
        //izvēlēties brīvi
        public static int NolasitKaInt()
        {
            Console.WriteLine("Print your number: ");
            try
            {
                int userNumber = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("ur number is: " + userNumber);
                return userNumber;
            }
            catch (Exception)
            {
                Console.WriteLine("ur values is not int type");
                return 0;
            } 
        }
        public static void Izvadit(string text)
        {
             Console.WriteLine(text);
        }
        public static void NomainitFonaKrasu()
        {
            Random random = new Random();
            ConsoleColor[] colors = (ConsoleColor[])Enum.GetValues(typeof(ConsoleColor));
            ConsoleColor thisColor = colors[random.Next(colors.Length)];
            Console.BackgroundColor = thisColor;

            //funkcija nomaina konsoles fona krāsu uz gadījuma (!) krāsu
        }
        public static void NomainitBurtuKrasu()
        {
            Random random = new Random();
            ConsoleColor[] colors = (ConsoleColor[])Enum.GetValues(typeof(ConsoleColor));
            ConsoleColor thisColor = colors[random.Next(colors.Length)];
            Console.ForegroundColor = thisColor;

            //funkcija nomaina konsoles burtu krāsu uz gadījuma (!) krāsu
        }
        public static void FormatetVardu(string fullname)
        {
            int maxValue = int.MaxValue;
            fullname.ToCharArray();
            Console.WriteLine("Ur Full name is: ");
            for (int i = 0; i < fullname.Length; i++)
            {
                if (i == 0)
                {
                    Console.WriteLine(Char.ToUpper(fullname[i]) + ".");
                }
                else if (fullname[i] == ' ')
                {
                    maxValue = i;
                    Console.WriteLine(fullname[i]);

                }
                else if (i == maxValue + 1)
                {
                    Console.WriteLine(Char.ToUpper(fullname[i]));
                }
                else if (i > maxValue)
                {
                    Console.WriteLine(fullname[i]);
                }
            }
            Console.WriteLine();
            //funkcija saņem vārdu un uzvārdu kā vienu string, piemēram, "Ivars
            //Zars". Un izvada to sekojošā formātā - vārda pirmais burts. Uzvārds (piemēram,
            //"I. Zars")
        }
        public static string IzveidotParoli(int garums)
        {
            const string symbols = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            StringBuilder password = new StringBuilder();
            Random rnd = new Random();
            while (0 < garums--)
            {
                password.Append(symbols[rnd.Next(symbols.Length)]);
            }
            return password.ToString();

            //funkcijWa veido un atgriež lietotājam drošo paroli. Paroles garumu
            //funkcija saņem. PAroles veidošanas principus jāizdomā pašam.
        }
        public static string SifretTekstu(string teksts)
        {
            UnicodeEncoding codeEncoding = new UnicodeEncoding();
            byte[] encoding = ProtectedData.Protect(codeEncoding.GetBytes(teksts), null, DataProtectionScope.CurrentUser);
            string encodingString = Convert.ToBase64String(encoding);
            return encodingString;
            //funkcija saņem kādu tekstu un šifrē to, izmantojot kādu no
            //vienkāršākiem šifrēšanas metodēm(piemēram, katram simbolam tiek pieskaitīs
            //kāds skaitlis)
        }
        public static string AtsifretTekstu(string teksts)
        {
            if (teksts == null)
            {
                Console.WriteLine("exist text!");
                return null;
            }
            byte[] encoding = Convert.FromBase64String(teksts);
            byte[] UNencoding = ProtectedData.Uprotect(encoding, null, DataProtectionScope.CurrentUser);
            string UNencodingText = UnicodeEncoding.Unicode.GetString(UNencoding);
            Console.WriteLine(UNencodingText);

            return null;

            //funkcija saņem šifrētu tekstu un atšifrē to, izmantojot iepriekš
            //definēto šifrēšanas metodi

        }
    }
}
