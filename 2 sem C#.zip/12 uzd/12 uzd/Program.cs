﻿using System;
using System.Text;
using System.Security.Cryptography;

namespace _12_uzd
{
    class Program : myConsole
    {

        static void Main(string[] args)
        {
            bool EndWork = true;
            string choose;
            string encodingUser = null;

            do
            {
                Console.WriteLine("Choose ur step");
                Console.WriteLine("1 - Check ur value ");
                Console.WriteLine("2 - Print text");
                Console.WriteLine("3 - Change fonts color");
                Console.WriteLine("4 - Change symbol fonts color");
                Console.WriteLine("5 - Your name");
                Console.WriteLine("6 - Generate password");
                Console.WriteLine("7 - Encoding text");
                Console.WriteLine("8 - Unencoding text");
                Console.WriteLine("9 - Date of day");
                Console.WriteLine("10 - End work");
                Console.WriteLine("Your choose:");
                choose = Console.ReadLine();
                switch (choose)
                {
                    case "1":
                        NolasitKaInt();
                        Console.WriteLine();
                        break;
                    case "2":
                        Console.WriteLine("Ur text: ");
                        string text = Console.ReadLine();
                        Izvadit(text);
                        Console.WriteLine();
                        break;
                    case "3":
                        NomainitFonaKrasu();
                        Console.Clear();
                        break;
                    case "4":
                        NomainitBurtuKrasu();
                        Console.Clear();
                        break;
                    case "5":
                        Console.WriteLine("Ur name and lastname: ");
                        string fullname = Console.ReadLine();
                        FormatetVardu(fullname);
                        Console.WriteLine();
                        break;
                    case "6":
                        int passwordValue;
                        Console.Clear();
                        Console.WriteLine("Ur password value: ");
                        passwordValue = int.Parse(Console.ReadLine());
                        Console.WriteLine("password is : " + IzveidotParoli(passwordValue));
                        Console.WriteLine();
                        break;
                    case "7":
                        Console.WriteLine("Encoding ur text: ");
                        string encodingUsers = Console.ReadLine();
                        encodingUser = SifretTekstu(encodingUsers);
                        Console.WriteLine("Ur text was encoding!");
                        Console.WriteLine();
                        break;
                    case "8":
                        Console.WriteLine("Unencoding text is: ");
                        AtsifretTekstu(encodingUser);
                        Console.WriteLine();
                        break;
                    case "9":
                        Console.WriteLine("To day is: " + tagad);
                        Console.WriteLine();
                        break;
                    case "10":
                        EndWork = false;
                        Console.WriteLine("Wors is end");
                        break;
                    default:
                        Console.WriteLine("Not found ur choose");
                        Console.WriteLine();
                        break;

                }

            }
            while (EndWork != false);
        }
    }
}
