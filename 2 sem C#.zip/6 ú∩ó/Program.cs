﻿namespace ConsoleApp3
{
    public class Program
    {
        static void Main (string[] args)
        {
            /* 1. Создать Item'Ы   
             * 2. Создать Cart 
               3. Создать Person
               4. Положить Item'Ы в Cart 
               5. Подёргать за методы Cart'а
               6. Положить Cart в Person
               7. Подёргать за методы Person */


            Item i1 = new Item();
            i1.Register("R-99", 30);
            Item i2 = new Item();
            i2.Register("R-301", 60);
            Item i3 = new Item();
            i3.Register("RE-45", 90);
            Item i4 = new Item();
            i4.Register("LongBow DMR", 120);

            Cart cart1 = new Cart(2);
            
        }
    }
}