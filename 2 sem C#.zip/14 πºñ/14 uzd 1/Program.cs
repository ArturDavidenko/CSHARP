﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14_uzd_1
{
    class Program
    {

        static void PrintArray(Course[] course)
        {
            foreach (var item in course)
            {
                if (item == null)
                {
                    Console.WriteLine("Array is empty");
                    return;
                }
                else
                {
                    item.PrintData();
                }
            }
        }

        static void PrintArrayToFile(Course[] course)
        {
            string writePath = @"C:\courseArray.txt";
            try
            {
                using (StreamWriter sw = new StreamWriter(writePath, false))
                {
                    foreach (var item in course)
                    {
                        if (item == null)
                        {
                            return;
                        }
                        else
                        {
                            sw.WriteLine($"Course name is: {item.name}");
                            sw.WriteLine($"Course credit points is: {item.creditpoints}");
                            string creditpointsNecessary = null;
                            if (item.necessarily == true)
                            {
                                creditpointsNecessary = "necessary!";
                            }
                            else if (item.necessarily == false)
                            {
                                creditpointsNecessary = "no necessary!";
                            }
                            sw.WriteLine($"Course {creditpointsNecessary}");
                            sw.WriteLine("  ");
                        }
                        Console.WriteLine("File is ready!");
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
        }

        static Course[] ReadyArrayFromFile()
        {
            Course[] readFromFileCourseArray = new Course[10];
            string path = @"C:\courseArray.txt";
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    int i = 1;
                    string line;
                    int courseAmount = 0;

                    while ((line = sr.ReadLine()) != null)
                    {
                        if (i == 1)
                        {
                            Course readCourse = new Course();
                            readFromFileCourseArray[courseAmount] = readCourse;
                            line = line.Substring(20);
                            line = line.Replace(".", String.Empty);
                            Convert.ToString(line);
                            readFromFileCourseArray[courseAmount].name = line;
                            Console.WriteLine($"Course name is: {readFromFileCourseArray[courseAmount].name}");
                        }
                        if(i == 2)
                        {
                            line = line.Substring(30);
                            line = line.Replace(".", String.Empty);
                            readFromFileCourseArray[courseAmount].creditpoints = Convert.ToInt32(line);
                            Console.WriteLine($"Course credit points is: {readFromFileCourseArray[courseAmount].creditpoints}");
                        }
                        if (i == 3)
                        {
                            line = line.Substring(6);
                            line = line.Replace(".", String.Empty);
                            if (line == "necessary!")
                            {
                                readFromFileCourseArray[courseAmount].necessarily = true;
                            }
                            else if (line == "no necessarry!")
                            {
                                readFromFileCourseArray[courseAmount].necessarily = false;
                            }
                            Console.WriteLine($"Course {line}");
                            courseAmount++;
                            Console.WriteLine();
                        }
                        if (i == 4)
                        {
                            i = 0;
                        }
                        i++;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                throw;
            }
            return readFromFileCourseArray;
        }

        static void Main(string[] args)
        {
            int CourseAmount = 0;
            bool EndWork = true;
            string choose;
            Course[] courses = new Course[10];
            do
            {
                Console.WriteLine("Choose steps");
                Console.WriteLine("1 - Registration course");
                Console.WriteLine("2 - Print course");
                Console.WriteLine("3 - Do file of course");
                Console.WriteLine("4 - Read course from file");
                Console.WriteLine("5 - End work");
                Console.WriteLine("Your choose: ");
                choose = Console.ReadLine();
                switch (choose)
                {
                    case "1":
                        Console.Clear();
                        Course course = new Course();
                        course.ReadData();
                        courses[CourseAmount] = course;
                        CourseAmount++;
                        break;
                    case "2":
                        Console.Clear();
                        PrintArray(courses);
                        break;
                    case "3":
                        Console.Clear();
                        PrintArrayToFile(courses);
                        break;
                    case "4":
                        Console.Clear();
                        courses = ReadyArrayFromFile();
                        break;
                    case "5":
                        Console.Clear();
                        EndWork = false;
                        Console.WriteLine("work is end");
                        break;
                    default:
                        Console.WriteLine("try again not this step!");
                        Console.WriteLine();
                        break;
                }

            } while (EndWork != false);
        }
    }
}
