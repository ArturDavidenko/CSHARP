﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _14_uzd_1
{
    class Course
    {
        public string name;
        public int creditpoints;
        public bool necessarily;

        public void ReadData()
        {
            Console.WriteLine("Name of course: ");
            name = Console.ReadLine();

            bool creditBool;
            do
            {
                Console.WriteLine("Credit points course: ");
                creditBool = int.TryParse(Console.ReadLine(), out creditpoints);
                if (creditBool == true)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("try again!");
                }
            } while (creditBool != true);

            bool necessaryBool = false;

            do
            {
                Console.WriteLine("necessary course? : ");
                string necessery = Console.ReadLine();
                if (necessery == "yes" || necessery == "true" || necessery == "t")
                {
                    necessaryBool = true;
                    necessarily = true;
                }
                else if (necessery == "no" || necessery == "false" || necessery == "f")
                {
                    necessaryBool = true;
                    necessarily = false;
                }
                else
                {
                    Console.WriteLine("try again!");
                }
            } while (necessaryBool != true);


        }

        public void PrintData()
        {
            Console.WriteLine($"Name of course is: {name}");
            Console.WriteLine($"Credit points is: {creditpoints * 1.5}");
            string creditpointsNecessary = null;
            if (necessarily == true)
            {
                creditpointsNecessary = "necessary!";
            }
            else if (necessarily == false)
            {
                creditpointsNecessary = "no neccessary!";
            }
            Console.WriteLine($"Course {creditpointsNecessary}");
            Console.WriteLine();
        }

    }
}
