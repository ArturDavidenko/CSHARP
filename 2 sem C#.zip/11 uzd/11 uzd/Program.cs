﻿using System;

namespace _11_uzd
{
    class Program
    {

        class Employee
        {
            string name;

            public string Name
            {
                get
                {
                    return name;
                }
                set
                {
                    if (value.Length <= 20)
                    {
                        name = value;
                    }
                    else
                    {
                        name = null;
                    }
                }
            }

            string LastName;

            public string lastname
            {
                get
                {
                    return LastName;
                }
                set
                {
                    if (lastname != null)
                    {
                        LastName = value;
                    }
                }
            }

           private int BornDate;

            public int borndate
            {
                get
                {
                    return BornDate;
                }
                set
                {
                    BornDate = value;
                }
            }

            int YearOld;

            public int yerold
            {
                get
                {
                    return YearOld = 2022 - BornDate;
                }
            }
        }

        static void Main(string[] args)
        {
            Employee V1 = new Employee();
            Console.WriteLine("Your name: ");
            V1.Name = Console.ReadLine();
            Console.WriteLine("Your lastname: ");
            V1.lastname = Console.ReadLine();
            Console.WriteLine($"Your name and lastname {V1.Name} {V1.lastname}");
            Console.WriteLine("Your born date: ");
            V1.borndate = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("You are: {0} year old", V1.yerold);
        }
    }
}
