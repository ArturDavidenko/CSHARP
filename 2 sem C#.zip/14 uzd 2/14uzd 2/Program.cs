﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace _14uzd_2
{
    class Program
    {
        static void DivisionOnNull()
        {
            Console.WriteLine("Firs number: ");
            int x = int.Parse(Console.ReadLine());
            Console.WriteLine("Second number: ");
            int y = int.Parse(Console.ReadLine());
            int result = x / y;
            Console.WriteLine($"Result is: {result}");
        }

        static void UnCorectConvert()
        {
            Console.WriteLine("Write true or false");
            string trueOrFlase = Console.ReadLine();
            Convert.ToBoolean(trueOrFlase);
        }

        static void OpenFile()
        {
            Console.WriteLine("Name of file: ");
            string fileName = Console.ReadLine();
            string d = @"C:\" + fileName + ".txt";
            using (StreamReader sr = new StreamReader(d))
            {
                Console.WriteLine("File ready!");
            }
        }

        static void OfTheRange()
        {
            int[] array = new int[1];
            array[0] = 5;
            Console.WriteLine("Number who want see: ");
            int index = int.Parse(Console.ReadLine());
            Console.WriteLine($"Value {index} is {array[index]}");
        }

        static void Main(string[] args)
        {
            bool EndWork = true;
            string choose;
            do
            {
                Console.WriteLine("Choose ur steps");
                Console.WriteLine("1 - Division on 0");
                Console.WriteLine("2 - Un correct convert");
                Console.WriteLine("3 - Un correct file");
                Console.WriteLine("4 - Of the range");
                Console.WriteLine("5 - end work");
                Console.WriteLine("Ur choose: ");
                choose = Console.ReadLine();
                switch (choose)
                {
                    case "1":
                        try
                        {
                            DivisionOnNull();
                        }
                        catch (DivideByZeroException)
                        {
                            Console.WriteLine("No division on 0");
                        }
                        break;
                    case "2":
                        try
                        {
                            UnCorectConvert();
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("Uncorrect text");
                        }
                        break;
                    case "3":
                        try
                        {
                            OpenFile();
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("File failed!");
                        }
                        break;
                    case "4":
                        try
                        {
                            OfTheRange();
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("idex is uncorrect");
                        }
                        break;
                    case "5":
                        EndWork = true;
                        Console.WriteLine("End work");
                        Console.WriteLine();
                        break;
                    default:
                        Console.WriteLine("not this choose!");
                        Console.WriteLine();
                        break;
                }
            } while (EndWork != false);
        }

        
    }
}
