﻿using System;

namespace _7_uzd_v2
{
    class Program
    {
        public class Point
        {
            public int x;
            public int y;
            public string color;



            public void Register()
            {
                Console.WriteLine($"ur x:{x}\t ur y:{y}\t ur color: {color}\t");
            }
        }

        public class Line
        {
            public Point A { get; set; }
            public Point B { get; set; }
            public string color { get; set; }


            public double GetLength()
            {
                double lens = Math.Sqrt(Math.Pow(B.x - A.x, 2));
                return lens;
            }
        }

        public class Data
        {
            public void Print(Line l)
            {
                Console.WriteLine($"ur lenght is: {l.GetLength()},({l.A.x};{l.A.y}),({l.B.x};{l.B.y})");
            }
        }
        static void Main(string[] args)
        {
            Point xyz = new Point();
            xyz.x = 2;
            xyz.y = 3;
            xyz.color = "grey";
            xyz.Register();

            Line l = new Line();
            l.GetLength();

            Data lxy = new Data();
            lxy.Print(l);

        }
    }
}
