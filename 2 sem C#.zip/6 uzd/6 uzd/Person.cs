﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Person
    {
        public string Name { get; set; } // Автосвойства - конструкция, которая будет развёрнута в методы Get Set для крнкретного поля. 
        public string Password { get; set; } 
        public Cart Cart { get; set; } // TODO: проверить на null перед вызовым CheckBalance.
        public double Balance { get; set; }


        /*
         * 1. Персона распоряжается корзиной 
         * 2. Корзина список таваров, который хочет купить пользователь.
         * 3. Корзина не должна иметь поведения.
           4. Товар не должен иметь поведения. => Товар и корзина - это POCO классы. 
         */
        public void PutItemsToCart(Item[] items) 
        {
            Cart = new Cart(items.Length);
            Cart.Items = items;
        }
        public void Register(string name, string password)
        {
            Name = name;
            Password = password;
        }
        public void CheckBalance()
        {
            bool IsPositiveBalance;
            if (this.Balance > Cart.GetFullPrice())
            {
                IsPositiveBalance = true;
            }
            else
            {
                IsPositiveBalance = false;
            }
            Console.WriteLine("Name: {0} | Password: {1} | Balance is Positive:{2}", this.Name, this.Password, IsPositiveBalance);
            Console.WriteLine("User's cart is:");
            Cart.GetCartSummary();
        }
    }
}
