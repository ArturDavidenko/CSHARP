﻿using System;

namespace ConsoleApp3
{
    public class Program
    {
        static void Main (string[] args)
        {
            /* 1. Создать Item'Ы   
             * 2. Создать Cart 
               3. Создать Person
               4. Положить Item'Ы в Cart 
               5. Подёргать за методы Cart'а
               6. Положить Cart в Person
               7. Подёргать за методы Person */


            Person p1 = new Person();
            p1.Register("arturs", "22233");
            p1.Cart = new Cart(2);

            p1.PutItemsToCart(new Item[]
            {
                new Item("r-99", 20),
                new Item("r-301", 40)
            });
            p1.Balance = 200;
            p1.CheckBalance();

            Console.WriteLine();

            Person p2 = new Person();
            p2.Register("Sergey", "123123");
            p2.Cart = new Cart(2);

            p2.PutItemsToCart(new Item[]
            {
                new Item("Longbow", 100),
                new Item("Havoc", 50)
            });
            p2.Balance = 100;
            p2.CheckBalance();
        }
    }
}