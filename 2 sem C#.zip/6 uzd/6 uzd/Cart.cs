﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Cart
    {
        public int ItemsAmount { get; set; }
        public Item[] Items { get; set; } // TODO: Положить какой либо товар в массив. 

        public Cart(int itemsAmount) // конструктор класса 
        {
            ItemsAmount = itemsAmount;
            Items = new Item[ItemsAmount];
        }

        public void PutItemsToCart(Item[] items)
        {
            Items = items;  
        }
      
        public double GetFullPrice()
        {
            double fullPrice = 0;
            foreach(var item in Items)
            {
                fullPrice += item.Price;
            }
            return fullPrice;
        }
        public void GetCartSummary()
        {
            Console.WriteLine("ItemsAmount:{0} FullPrice: {1}", ItemsAmount, GetFullPrice());
            Console.WriteLine("Items: ");
            foreach (var item in Items)
            {
                Console.WriteLine(item.GetStringData());
            }
        }

    }
   
}
