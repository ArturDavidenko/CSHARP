﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    public class Item
    {
        //class with fields and without methods is POCO or Plain Old CLR Objects
        public string Name;
        public double Price;
        

        public Item(string name, double price)
        {
            Name = name;
            Price = price;
        } 

        public void Register(string name, double price)
        {
            Name = name;
            Price = price;
        }

        public string GetStringData()
        {
            return this.Name + " " + this.Price; // конкатенация 3-х строк.
        }

    }
}
