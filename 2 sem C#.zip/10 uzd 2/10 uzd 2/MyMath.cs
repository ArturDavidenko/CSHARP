﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _10_uzd_2
{
    class MyMath
    {
        public static void MyMax(params int[] numbers)
        {
            int number = 0;
            int ArrayMaxNumber = 0;

            foreach (var ArrayNumber in numbers)
            {
                if (number == 0)
                {
                    ArrayMaxNumber = ArrayNumber;
                }
                else if (ArrayNumber > ArrayMaxNumber)
                {
                    ArrayMaxNumber = ArrayNumber;
                }
            }
            Console.WriteLine($"Array max number is: {ArrayMaxNumber}");
        }

        public static void MyMin(params int[] numbers)
        {
            int number = 0;
            int ArrayMinNumber = 0;

            foreach (var ArrayNumbers in numbers)
            {
                if (number == 0)
                {
                    ArrayMinNumber = ArrayNumbers;
                }
                else if (ArrayNumbers < ArrayMinNumber)
                {
                    ArrayMinNumber = ArrayNumbers;
                }
            }
            Console.WriteLine($"Array max number is: {ArrayMinNumber}");
        }
    }
}
