﻿using System;

namespace _10_uzd_2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Write your size of array: ");
            int numbers = Convert.ToInt32(Console.ReadLine());
            int[] numbersArray = new int[numbers];

            for (int i = 0; i < numbers; i++)
            {
                Console.Write("Write int number: ");
                int numberReg = int.Parse(Console.ReadLine());
                numbersArray[i] = numberReg;
            }

            bool end = false;


            do
            {
                Console.WriteLine("Choose your step: ");
                Console.WriteLine("1 - Find Max number of array");
                Console.WriteLine("2 - Find Min number of array");
                Console.WriteLine("3 - end work");
                Console.WriteLine("Your choose: ");
                int choose = Convert.ToInt32(Console.ReadLine());

                switch (choose)
                {
                    case 1:
                        MyMath.MyMax(numbersArray);
                        break;

                    case 2:
                        MyMath.MyMin(numbersArray);
                        break;

                    case 3:
                        Console.WriteLine("End work");
                        end = true;
                        break;
                    default:
                        Console.WriteLine("Not found step!");
                        break;
                }

            } while (end != true);
            
        }
    }
}
