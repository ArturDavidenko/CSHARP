﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Timer
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer = new DispatcherTimer();

        int purpleCarCoordinate = 39;
        int redCarCoordinate = 670;
        int yellowCarCoordinate = 320;
        int orangeCarCoordinate = 30;

        public MainWindow()
        {
            InitializeComponent();
            timer.Interval = TimeSpan.FromMilliseconds(0.50); 
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            if (btnStart.Content.ToString() == "START")
            {
                timer.Tick += Timer_Tick;
                timer.Start();
                btnStart.Content = "STOP";
            }
            else
            {
                timer.Stop();
                btnStart.Content = "START";
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            Canvas.SetLeft(purpleCar, purpleCarCoordinate++);
            Canvas.SetLeft(redCar, redCarCoordinate--);

            if (purpleCarCoordinate == 200)
            {
                BitmapImage bi1 = new BitmapImage();
                bi1.BeginInit();
                bi1.UriSource = new Uri("C:/Users/Home/Desktop/LLU/itf 3 sem/Programmesana Windows vide/6 - Timer/img/yellow.png", UriKind.Relative);
                bi1.EndInit();
                leftStreet.Source = bi1;
                rightStreet.Source = bi1;
            }

            if (purpleCarCoordinate == 250)
            {
                BitmapImage bi1 = new BitmapImage();
                bi1.BeginInit();
                bi1.UriSource = new Uri("C:/Users/Home/Desktop/LLU/itf 3 sem/Programmesana Windows vide/6 - Timer/img/red.png", UriKind.Relative);
                bi1.EndInit();
                leftStreet.Source = bi1;
                rightStreet.Source = bi1;
            }


            if (purpleCarCoordinate == 300)
            {
                BitmapImage bi1 = new BitmapImage();
                bi1.BeginInit();
                bi1.UriSource = new Uri("C:/Users/Home/Desktop/LLU/itf 3 sem/Programmesana Windows vide/6 - Timer/img/yellow.png", UriKind.Relative);
                bi1.EndInit();
                topStreet.Source = bi1;
                botStreet.Source = bi1;
            }


            if (purpleCarCoordinate == 350)
            {
                BitmapImage bi1 = new BitmapImage();
                bi1.BeginInit();
                bi1.UriSource = new Uri("C:/Users/Home/Desktop/LLU/itf 3 sem/Programmesana Windows vide/6 - Timer/img/green.png", UriKind.Relative);
                bi1.EndInit();
                topStreet.Source = bi1;
                botStreet.Source = bi1;
            }

            if (purpleCarCoordinate > 550)
            {
                Canvas.SetTop(yellowCar, yellowCarCoordinate--);
                Canvas.SetTop(magentaCar, orangeCarCoordinate++);
            }

            if (purpleCarCoordinate == 1000)
            {
                purpleCarCoordinate = 39;
                redCarCoordinate = 670;
                yellowCarCoordinate = 320;
                orangeCarCoordinate = 30;

                Canvas.SetTop(yellowCar, yellowCarCoordinate);
                Canvas.SetTop(magentaCar, orangeCarCoordinate);
            }
        }
    }
}
