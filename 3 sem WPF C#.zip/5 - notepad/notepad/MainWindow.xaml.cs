﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Documents;
using Microsoft.Win32;
using SaveFileDialog = Microsoft.Win32.SaveFileDialog;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;
using System.Windows.Media;
using System.Windows.Forms;
using System.Drawing;
using FontFamily = System.Windows.Media.FontFamily;
using System.Runtime.CompilerServices;
using System.Windows.Controls;


namespace notepad
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        bool saved = false;
        string chosenFile = "";
        int i = 0;

        SaveFileDialog saveFileDialog = new SaveFileDialog()
        {
            Filter = "Text Files(*.txt)|*.txt|Rich Text Files(*.rtf)|*.rtf|All(*.*)|*"
        };

        private void MenuNew_Click(object sender, RoutedEventArgs e)
        {
            userInput.Document.Blocks.Clear();
            saved = false;
        }

        private void MenuOpen_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFiledialog = new OpenFileDialog();
            openFiledialog.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            if (openFiledialog.ShowDialog() == true)
            {
                userInput.Document.Blocks.Clear();
                userInput.Document.Blocks.Add(new Paragraph(new Run(File.ReadAllText(openFiledialog.FileName))));
                chosenFile = openFiledialog.FileName;
            }
            saved = true;
        }

        private void MenuSave_Click(object sender, RoutedEventArgs e)
        {
            string userInputText = new TextRange(userInput.Document.ContentStart, userInput.Document.ContentEnd).Text;
            if (userInputText != "" && saved == false)
            {
                saved = true;
                MenuSaveAs_Click(sender, e);
            }
            else
            {
                string modifiedUserInputText = new TextRange(userInput.Document.ContentStart, userInput.Document.ContentEnd).Text;
                File.WriteAllText(chosenFile, modifiedUserInputText);
            }
        }

        private void MenuSaveAs_Click(object sender, RoutedEventArgs e)
        {
            if (saveFileDialog.ShowDialog() == true)
            {
                string userInputText = new TextRange(userInput.Document.ContentStart, userInput.Document.ContentEnd).Text;
                File.WriteAllText(saveFileDialog.FileName, userInputText);
            }
        }

        private void MenuFormat_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.RichTextBox rtb = new System.Windows.Forms.RichTextBox();
            FontDialog fd = new FontDialog();
            if (fd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                FontFamilyConverter ffc = new FontFamilyConverter();
                rtb.Font = fd.Font;

                userInput.Document.FontSize = fd.Font.Size;

                userInput.Document.FontFamily = (FontFamily)ffc.ConvertFromString(fd.Font.Name);


                if (rtb.Font.Bold)
                    userInput.FontWeight = FontWeights.Bold;
                else
                    userInput.FontWeight = FontWeights.Normal;

                if (rtb.Font.Italic)
                    userInput.FontStyle = FontStyles.Italic;
                else
                    userInput.FontStyle = FontStyles.Normal;
            }
        }

        private void MenuWordWrap_Click(object sender, RoutedEventArgs e)
        {
            if (!wordwrap.IsChecked)
            {
                userInput.HorizontalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Visible;
                userInput.Document.PageWidth = 1500;
            }
            else
            {
                userInput.HorizontalScrollBarVisibility = System.Windows.Controls.ScrollBarVisibility.Hidden;
                userInput.Document.PageWidth = ActualHeight;
            }
        }

        private void CharCounter()
        {
            string userInputText = new TextRange(userInput.Document.ContentStart, userInput.Document.ContentEnd).Text;
            i = userInputText.Length - 2;
            string charCount = i.ToString();
            CharCount.Text = "Characters(with spaces): " + charCount;
        }

        private void TextChanged(object sender, TextChangedEventArgs e)
        {
            CharCounter();
        }

    }
}
