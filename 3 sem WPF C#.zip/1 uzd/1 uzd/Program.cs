﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_uzd
{
    class Program
    {
 
        static void Main(string[] args)
        {
            Console.WriteLine("izveletis grutibas pakapi no 1 lidz 5: ");
            int choose = Convert.ToInt32(Console.ReadLine());

            double PareiziFLAG = 0;
            int NepareiziFLAG = 0;
            double Atzime;
            double amount = 0;
            string A;


            bool EndWork = true;

            do
            {
                switch (choose)
                {
                    case 1:
                        Random rnd1 = new Random();
                        int a1 = rnd1.Next(1, 5);
                        int b = rnd1.Next(1, 5);
                        int sum = a1 + b;

                        Console.WriteLine(a1 + "+" + b + "= ");
                        int number = Convert.ToInt32(Console.ReadLine());
                        amount++;

                        if (number == sum)
                        {
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.WriteLine("Pareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            PareiziFLAG++;
                        }
                        else if (number != sum)
                        {
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.WriteLine("Nepareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            NepareiziFLAG++;
                        }
                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork = Console.ReadLine();

                        if (StopWork == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork == "n")
                        {
                            if (PareiziFLAG == 0)
                            {
                                Atzime = 0;
                            }
                            else if (PareiziFLAG == amount)
                            {
                                Atzime = 10;
                            }
                            else
                            {
                                Atzime = PareiziFLAG / amount;
                            }

                            Atzime = Math.Round(Atzime, 1);
                            A = " " + Atzime;

                            Console.WriteLine($"Cik jautajumi: {amount} ||Jusu pareizi varinti ir: {PareiziFLAG} || Jusu NEpareizi varianti ir: {NepareiziFLAG} || Jusu atzime: {A.Replace("0,", " ")}");
                            Console.ReadLine();
                            EndWork = true;
                        }
                        break;
                    case 2:
                        Random rnd2 = new Random();
                        int a2 = rnd2.Next(1, 15);
                        int b2 = rnd2.Next(1, 15);
                        int sum2 = a2 * b2;

                        Console.WriteLine(a2 + "*" + b2 + "= ");
                        int number2 = Convert.ToInt32(Console.ReadLine());
                        amount++;
                        if (number2 == sum2)
                        {
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.WriteLine("Pareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            PareiziFLAG++;
                        }
                        else if (number2 != sum2)
                        {
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.WriteLine("Nepareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            NepareiziFLAG++;
                        }
                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork2 = Console.ReadLine();

                        if (StopWork2 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork2 == "n")
                        {
                            if (PareiziFLAG == 0)
                            {
                                Atzime = 0;
                            }
                            else if (PareiziFLAG == amount)
                            {
                                Atzime = 10;
                            }
                            else
                            {
                                Atzime = PareiziFLAG / amount;
                                
                            }

                            Atzime = Math.Round(Atzime, 1);
                            A = " " + Atzime;

                            Console.WriteLine($"Cik jautajumi: {amount} ||Jusu pareizi varinti ir: {PareiziFLAG} || Jusu NEpareizi varianti ir: {NepareiziFLAG} || Jusu atzime: {A.Replace("0,", " ")}");
                            Console.ReadLine();
                            EndWork = true;
                        }
                        break;

                    case 3:
                        Random rnd3 = new Random();
                        int a3 = rnd3.Next(1, 25);
                        int b3 = rnd3.Next(1, 25);
                        int sum3 = a3 / b3;

                        Console.WriteLine(a3 + "/" + b3 + "= ");
                        int number3 = Convert.ToInt32(Console.ReadLine());
                        amount++;
                        if (number3 == sum3)
                        {
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.WriteLine("Pareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            PareiziFLAG++;
                        }
                        else if (number3 != sum3)
                        {
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.WriteLine("Nepareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            NepareiziFLAG++;
                        }
                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork3 = Console.ReadLine();

                        if (StopWork3 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork3 == "n")
                        {
                            if (PareiziFLAG == 0)
                            {
                                Atzime = 0;
                            }
                            else if (PareiziFLAG == amount)
                            {
                                Atzime = 10;
                            }
                            else
                            {
                                Atzime = PareiziFLAG / amount;
                                
                            }
                            Atzime = Math.Round(Atzime, 1);
                            A = " " + Atzime;

                            Console.WriteLine($"Cik jautajumi: {amount} ||Jusu pareizi varinti ir: {PareiziFLAG} || Jusu NEpareizi varianti ir: {NepareiziFLAG} || Jusu atzime: {A.Replace("0,", " ")}");
                            Console.ReadLine();
                            EndWork = true;
                        }
                        break;

                    case 4:
                        Random rnd4 = new Random();
                        int a4 = rnd4.Next(1, 25);
                        int b4 = rnd4.Next(1, 25);
                        int sum4 = a4 * b4;

                        Console.WriteLine(a4 + "*" + b4 + "= ");
                        int number4 = Convert.ToInt32(Console.ReadLine());
                        amount++;
                        if (number4 == sum4)
                        {
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.WriteLine("Pareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            PareiziFLAG++;
                        }
                        else if (number4 != sum4)
                        {
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.WriteLine("Nepareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            NepareiziFLAG++;
                        }
                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork4 = Console.ReadLine();

                        if (StopWork4 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork4 == "n")
                        {
                            if (PareiziFLAG == 0)
                            {
                                Atzime = 0;
                            }
                            else if (PareiziFLAG == amount)
                            {
                                Atzime = 10;
                            }
                            else
                            {
                                Atzime = PareiziFLAG / amount;
                                
                            }
                            Atzime = Math.Round(Atzime, 1);
                            A = " " + Atzime;

                            Console.WriteLine($"Cik jautajumi: {amount} ||Jusu pareizi varinti ir: {PareiziFLAG} || Jusu NEpareizi varianti ir: {NepareiziFLAG} || Jusu atzime: {A.Replace("0,", " ")}");
                            Console.ReadLine();
                            EndWork = true;
                        }
                        break;


                    case 5:
                        Random rnd5 = new Random();
                        int a5 = rnd5.Next(1, 85);
                        int b5 = rnd5.Next(1, 85);
                        int sum5 = a5 * b5;

                        Console.WriteLine(a5 + "*" + b5 + "= ");
                        int number5 = Convert.ToInt32(Console.ReadLine());
                        amount++;
                        if (number5 == sum5)
                        {
                            Console.BackgroundColor = ConsoleColor.Green;
                            Console.WriteLine("Pareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            PareiziFLAG++;
                        }
                        else if (number5 != sum5)
                        {
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.WriteLine("Nepareizi");
                            Console.BackgroundColor = ConsoleColor.Black;
                            NepareiziFLAG++;
                        }
                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork5 = Console.ReadLine();

                        if (StopWork5 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork5 == "n")
                        {
                            if (PareiziFLAG == 0)
                            {
                                Atzime = 0;
                            }
                            else if (PareiziFLAG == amount)
                            {
                                Atzime = 10;
                            }
                            else
                            {
                                Atzime = PareiziFLAG / amount;
                            }
                            Atzime = Math.Round(Atzime, 1);
                            A = " " + Atzime;

                            Console.WriteLine($"Cik jautajumi: {amount} ||Jusu pareizi varinti ir: {PareiziFLAG} || Jusu NEpareizi varianti ir: {NepareiziFLAG} || Jusu atzime: {A.Replace("0,", " ")}");
                            Console.ReadLine();
                            EndWork = true;
                        }
                        break;
                    default:
                        Console.WriteLine("nav so izveles!");
                        break;
                }

            } while (EndWork!=true);
        }
    }
}
