﻿using System.ComponentModel;

namespace ValidationWindow
{
    class ViewModel : INotifyPropertyChanged
    {
        public ViewModel()
        {
            Model = new Model()
            {
                Name = "Arturs",
                BirthdayDate = "16.09.2002",
                PhoneNumber = "27029494",
                Email = "artursdav@inbox.lv",
                WebPage = "www.llu.lv"

            };
        }

        public Model Model
        {
            get; set;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
