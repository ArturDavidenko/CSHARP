﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Windows;

namespace ValidationWindow
{
    class Model : INotifyPropertyChanged, IDataErrorInfo
    {
        private static readonly string NameRegex = "^[A-Z][a-z]{2,15}$";
        private static readonly string BirthdayDateRegex = @"^(0[1-9]|[12][0-9]|3[01]).(0[1-9]|1[012]).(19|20)\d\d$";
        private static readonly string PhoneNumberRegex = @"^[+]*[(]{0,1}[0-9]{1,4}[)]{0,1}[-\s\./0-9]*$";
        private static readonly string WebPageRegex = @"^(www\.)([\w]+)\.([\w]+)$";
        private static readonly string EmailRegex = @"^([\w]+)@([\w]+)\.([\w]+)$";

        static readonly string[] ValidatedProperties = 
            {
            "Name",
            "BirthdayDate",
            "PhoneNumber",
            "WebPage",
            "Email"
            };

        private string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                OnPropertyChanged("Name");

            }
        }

        private string _birthdayDate;
        public string BirthdayDate
        {
            get { return _birthdayDate; }
            set
            {
                _birthdayDate = value;
                OnPropertyChanged("BirthdayDate");
            }
        }

        private string _phoneNumber;
        public string PhoneNumber
        {
            get { return _phoneNumber; }
            set
            {
                _phoneNumber = value;
                OnPropertyChanged("PhoneNumber");
            }
        }

        private string _webPage;
        public string WebPage
        {
            get { return _webPage; }
            set
            {
                _webPage = value;
                OnPropertyChanged("WebPage");
            }
        }


        private string _email;
        public string Email
        {
            get { return _email; }
            set
            {
                _email = value;
                OnPropertyChanged("Email");
            }
        }

        public bool IsValid
        {
            get
            {
                foreach (var property in ValidatedProperties)
                {
                    switch (property)
                    {
                        case "Name":
                            if (Validate(property, NameRegex) != null)
                            {
                                return false;
                            }
                            break;
                        case "BirthdayDate":
                            if (Validate(property, BirthdayDateRegex) != null)
                            {
                                return false;
                            }
                            break;
                        case "PhoneNumber":
                            if (Validate(property, PhoneNumberRegex) != null)
                            {
                                return false;
                            }
                            break;
                        case "WebPage":
                            if (Validate(property, WebPageRegex) != null)
                            {
                                return false;
                            }
                            break;
                        case "Email":
                            if (Validate(property, EmailRegex) != null)
                            {
                                return false;
                            }
                            break;
                    }
                }
                return true;
            }
        }

        public string Error
        {
            get { return "error"; }
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }

        public string this[string columnName]
        {
            get
            {
                switch (columnName)
                {
                    case "Name":
                        return Validate(columnName, NameRegex);

                    case "BirthdayDate":
                        return Validate(columnName, BirthdayDateRegex);

                    case "PhoneNumber":
                        return Validate(columnName, PhoneNumberRegex);

                    case "WebPage":
                        return Validate(columnName, WebPageRegex);

                    case "Email":
                        return Validate(columnName, EmailRegex);

                }
                return null;
            }
        }

        private string Validate(string propertyName, string regex)
        {
            string validationMessage = string.Empty;

            Regex r = new Regex(regex);

            switch (propertyName)
            {
                case "Name":
                    if (r.IsMatch(Name))
                    {
                        return null;
                    }
                    else
                    {
                        validationMessage =  "Name is invalid";
                        return validationMessage;
                    }
                case "BirthdayDate":
                    if (r.IsMatch(BirthdayDate))
                    {
                        return null;
                    }
                    else
                    {
                        validationMessage = "Birthday Date is invalid";
                        return validationMessage;
                    }
                case "PhoneNumber":
                    if (r.IsMatch(PhoneNumber))
                    {
                        return null;
                    }
                    else
                    {
                        validationMessage = "Phone number is invalid";
                        return validationMessage;
                    }
                case "WebPage":
                    if (r.IsMatch(WebPage))
                    {
                        return null;
                    }
                    else
                    {
                        validationMessage = "Web Page is invalid";
                        return validationMessage;
                    }
                case "Email":
                    if (r.IsMatch(Email))
                    {
                        return null;
                    }
                    else
                    {
                        validationMessage = "Email is invalid";
                        return validationMessage;
                    }
            }
            return validationMessage;
        }
    }
}
