﻿using System.Windows;
using System.Windows.Controls;

namespace ValidationWindow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (
                Validation.GetHasError(NameInput) ||
                Validation.GetHasError(BirthdayInput) || 
                Validation.GetHasError(PhoneInput) || 
                Validation.GetHasError(EmailInput) || 
                Validation.GetHasError(WebPageInput))
            {
                MessageBox.Show("Data is incorrect", "Attention", MessageBoxButton.OK, MessageBoxImage.Error);

            }
            else
            {
                MessageBox.Show("All data is correct", "Data is correct", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            
        }


    }
}
