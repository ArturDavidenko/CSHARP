﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace RegexUSING
{
    class Program
    {
        static void Main(string[] args)
        {
            string TaskA = "Arturs";
            Regex regexA = new Regex("[A][a-z]{5}");

            string TaskB = "AC309437";
            Regex regexB = new Regex("[a-zA-Z]{2}[0-9]{6}");

            string TaskC = "LV-1005";
            Regex regexC = new Regex("[a-zA-Z]{2}-[0-9]{4}");

            string TaskD = "InfT2033";
            Regex regexD = new Regex("[A-Z]{1}[a-z]{2}[A-Z]{1}[0-9]{4}");
        }
    }
}
