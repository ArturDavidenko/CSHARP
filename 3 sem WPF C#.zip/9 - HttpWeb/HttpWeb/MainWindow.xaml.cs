﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.Protocols;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HttpWeb
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// url = 'https://www.llu.lv/lv/kontakti-un-rekviziti'
    public partial class MainWindow : Window
    {

        List<SearchResponse> responseList = new List<SearchResponse>();

        public MainWindow()
        {
            InitializeComponent();
        }

        bool phonesIsSelected = false;
        bool bankIsSelected = false;

        Regex bankPattern = new Regex(@"LV[0-9]{2}[A-Z]{4}[0-9]{13}");
        Regex UriRegex = new Regex(@"^(www\.)([\w]+)\.([\w]+)$");

        private void SearchBtn_Click(object sender, RoutedEventArgs e)
        {

            responseList.Clear();

            try
            {
                HttpWebRequest WebReg = (HttpWebRequest)HttpWebRequest.Create(URL.Text);
                WebReg.Method = "GET";

                HttpWebResponse webRes = (HttpWebResponse)WebReg.GetResponse();
                StreamReader webSourse = new StreamReader(webRes.GetResponseStream());
                string sourse = webSourse.ReadToEnd();
                Console.WriteLine(sourse);
                webRes.Close();

                if (phonesIsSelected == true)
                {
                    
                    foreach (Match m in Regex.Matches(sourse, @"(Tālr.: )(\d{8})"))
                    {
                        string result = m.Value.ToString().Substring(7, 8);
                        responseList.Add(new SearchResponse() { Response = result });
                    }

                    foreach (Match m in Regex.Matches(sourse, @"(Tālrunis: )(\d{8})"))
                    {
                        string result = m.Value.ToString().Substring(10, 8);
                        responseList.Add(new SearchResponse() { Response = result });
                    }
                    DataResult.ItemsSource = responseList;
                    return;
                }

                if (bankIsSelected == true)
                {

                    foreach (Match с in Regex.Matches(sourse, bankPattern.ToString()))
                    {
                        responseList.Add(new SearchResponse() { Response = с.ToString() });
                    }
                    DataResult.ItemsSource = responseList;
                    return;
                }
                else
                {
                    MessageBox.Show("Select what info to gather.");
                }

            }
            catch (Exception)
            {
                MessageBox.Show("URL is not valid.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }

        private void PhoneNumberCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton press = (RadioButton)sender;
            if (press.IsChecked == true)
            {
                phonesIsSelected = true;
                bankIsSelected = false;
            }
            
        }

        private void BankAccountNumberCheckBox_Checked(object sender, RoutedEventArgs e)
        {

            RadioButton press = (RadioButton)sender;
            if (press.IsChecked == true)
            {
                bankIsSelected = true;
                phonesIsSelected = false;
            } 
        }

        public class SearchResponse
        {
            public string Response { get; set; }
        }

        private void ClearBtn_Click(object sender, RoutedEventArgs e)
        {
            DataResult.ItemsSource = " ";
        }
    }
}
