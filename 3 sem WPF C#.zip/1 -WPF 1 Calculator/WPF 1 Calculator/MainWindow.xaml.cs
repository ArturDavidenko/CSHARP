﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF_1_Calculator
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        string choose = "";
        Button btn = new Button();

        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            ClearColor();
            btn = sender as Button;
            btn.Background = Brushes.Green;
            choose = "+";
        }

        private void Minus_Click(object sender, RoutedEventArgs e)
        {
            ClearColor();
            btn = sender as Button;
            btn.Background = Brushes.Green;
            choose = "-";
        }

        private void Multiplication_Click(object sender, RoutedEventArgs e)
        {
            ClearColor();
            btn = sender as Button;
            btn.Background = Brushes.Green;
            choose = "*";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClearColor();
            btn = sender as Button;
            btn.Background = Brushes.Green;
            choose = "/";
        }

        private void Equals_Click(object sender, RoutedEventArgs e)
        {
            switch (choose)
            {
                case "+":
                    double res;
                    res = Convert.ToDouble(FirstNumber.Text) + Convert.ToDouble(SecondNumber.Text);
                    Resolution.Text = Convert.ToString(res);
                    break;
                case "-":
                    double res2;
                    res2 = Convert.ToDouble(FirstNumber.Text) - Convert.ToDouble(SecondNumber.Text);
                    Resolution.Text = Convert.ToString(res2);
                    break;
                case "*":
                    double res3;
                    res3 = Convert.ToDouble(FirstNumber.Text) * Convert.ToDouble(SecondNumber.Text);
                    Resolution.Text = Convert.ToString(res3);
                    break;
                case "/":
                    double res4;
                    res4 = Convert.ToDouble(FirstNumber.Text) / Convert.ToDouble(SecondNumber.Text);
                    Resolution.Text = Convert.ToString(res4);
                    break;
                default:
                    break;
            }
        }

        public void ClearColor()
        {
            btn.Background = Brushes.Transparent;
        }
    }
}
