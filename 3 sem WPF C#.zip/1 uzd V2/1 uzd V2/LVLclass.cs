﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_uzd_V2
{
    class LVLclass
    {
        public int A;
        public int B;
        public static int Sum;
        public Random Rnd;
        public int CountP = 0;
        public int CountNP = 0;
        public static int Number;

        public void LVL1()
        {
            Rnd = new Random();
            A = Rnd.Next(1, 5);
            B = Rnd.Next(1, 5);
            Sum = A + B;
            Console.WriteLine("{0} + {1} =", A, B);
            Number = Convert.ToInt32(Console.ReadLine());
        }

        public void LVL2()
        {
            Rnd = new Random();
            A = Rnd.Next(1, 15);
            B = Rnd.Next(1, 15);
            Sum = A - B;
            Console.WriteLine("{0} - {1} = ", A, B);
            Number = Convert.ToInt32(Console.ReadLine());
        }


        public void LVL3()
        {
            Rnd = new Random();
            A = Rnd.Next(1, 15);
            B = Rnd.Next(1, 15);
            Sum = A * B;
            Console.WriteLine("{0} * {1} = ", A, B);
            Number = Convert.ToInt32(Console.ReadLine());
        }

        public void LVL4()
        {
            Rnd = new Random();
            A = Rnd.Next(1, 25);
            B = Rnd.Next(1, 25);
            Sum = A / B;
            Console.WriteLine("{0} / {1} = ", A, B);
            Number = Convert.ToInt32(Console.ReadLine());
        }

        public void LVL5()
        {
            Rnd = new Random();
            A = Rnd.Next(1, 25);
            B = Rnd.Next(1, 25);
            Sum = A * B;
            Console.WriteLine("{0} * {1} = ", A, B);
            Number = Convert.ToInt32(Console.ReadLine());
        }


        public void IfElse()
        {
            if (Number == Sum)
            {
                Console.BackgroundColor = ConsoleColor.Green;
                Console.WriteLine("Pareizi");
                Console.BackgroundColor = ConsoleColor.Black;
                CountP++;
            }
            else if (Number != Sum)
            {
                Console.BackgroundColor = ConsoleColor.Red;
                Console.WriteLine("Nepareizi");
                Console.BackgroundColor = ConsoleColor.Black;
                CountNP++;
            }
        }

        public void Print()
        {
            Console.WriteLine($"Jusu pareizi varinti ir: {CountP} || Jusu NEpareizi varianti ir: {CountNP}");
            Console.ReadLine();
        }

    }
}
