﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1_uzd_V2
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("izveletis grutibas pakapi no 1 lidz 5: ");
            int choose = Convert.ToInt32(Console.ReadLine());

            bool EndWork = true;

            do
            {
                switch (choose)
                {
                    case 1:
                        LVLclass lvl1 = new LVLclass();
                        lvl1.LVL1();
                        lvl1.IfElse();
                        
                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork1 = Console.ReadLine();

                        if (StopWork1 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork1 == "n")
                        {
                            lvl1.Print();
                            EndWork = true;
                        }
                        break;

                    case 2:
                        LVLclass lvl2 = new LVLclass();
                        lvl2.LVL2();
                        lvl2.IfElse();

                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork2 = Console.ReadLine();

                        if (StopWork2 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork2 == "n")
                        {
                            lvl2.Print();
                            EndWork = true;
                        }
                        break;

                    case 3:
                        LVLclass lvl3 = new LVLclass();
                        lvl3.LVL3();
                        lvl3.IfElse();

                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork3 = Console.ReadLine();

                        if (StopWork3 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork3 == "n")
                        {
                            lvl3.Print();
                            EndWork = true;
                        }
                        break;

                    case 4:
                        LVLclass lvl4 = new LVLclass();
                        lvl4.LVL4();
                        lvl4.IfElse();

                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork4 = Console.ReadLine();

                        if (StopWork4 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork4 == "n")
                        {
                            lvl4.Print();
                            EndWork = true;
                        }
                        break;


                    case 5:
                        LVLclass lvl5 = new LVLclass();
                        lvl5.LVL5();
                        lvl5.IfElse();

                        Console.WriteLine("Vai turpinat darbu? (j/n)");
                        string StopWork5 = Console.ReadLine();

                        if (StopWork5 == "j")
                        {
                            EndWork = false;
                        }
                        else if (StopWork5 == "n")
                        {
                            lvl5.Print();
                            EndWork = true;
                        }
                        break;

                    default:
                        Console.WriteLine("nav so izveles!");
                        break;
                }
            } while (EndWork != true);

        }
    }
}
