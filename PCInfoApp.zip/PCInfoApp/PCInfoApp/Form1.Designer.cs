﻿namespace PCInfoApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            label1 = new Label();
            LabelCpu = new Label();
            LabelRam = new Label();
            LabelDriver = new Label();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = SystemColors.WindowFrame;
            button2.BackgroundImageLayout = ImageLayout.None;
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            button2.ForeColor = Color.White;
            button2.Location = new Point(307, 373);
            button2.Name = "button2";
            button2.Size = new Size(156, 45);
            button2.TabIndex = 1;
            button2.Text = "Start";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            label1.AutoSize = true;
            label1.Font = new Font("Bahnschrift Condensed", 36F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(240, 9);
            label1.Name = "label1";
            label1.Size = new Size(294, 58);
            label1.TabIndex = 2;
            label1.Text = "PC INFO TRACKER";
            // 
            // LabelCpu
            // 
            LabelCpu.AutoSize = true;
            LabelCpu.Font = new Font("Arial", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            LabelCpu.Location = new Point(281, 116);
            LabelCpu.Name = "LabelCpu";
            LabelCpu.Size = new Size(177, 34);
            LabelCpu.TabIndex = 3;
            LabelCpu.Text = "Cpu Usage:";
            // 
            // LabelRam
            // 
            LabelRam.AutoSize = true;
            LabelRam.Font = new Font("Arial", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            LabelRam.Location = new Point(281, 197);
            LabelRam.Name = "LabelRam";
            LabelRam.Size = new Size(207, 34);
            LabelRam.TabIndex = 4;
            LabelRam.Text = "Aviable RAM: ";
            // 
            // LabelDriver
            // 
            LabelDriver.AutoSize = true;
            LabelDriver.Font = new Font("Arial", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 204);
            LabelDriver.Location = new Point(281, 271);
            LabelDriver.Name = "LabelDriver";
            LabelDriver.Size = new Size(161, 34);
            LabelDriver.TabIndex = 5;
            LabelDriver.Text = "Disk Time:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(LabelDriver);
            Controls.Add(LabelRam);
            Controls.Add(LabelCpu);
            Controls.Add(label1);
            Controls.Add(button2);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button2;
        private Label label1;
        private Label LabelCpu;
        private Label LabelRam;
        private Label LabelDriver;
    }
}
