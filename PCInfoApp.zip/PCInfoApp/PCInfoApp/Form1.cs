using System.Diagnostics;

namespace PCInfoApp
{
    public partial class Form1 : Form
    {
        private bool stopCpuThread = false;
        private bool stopRamThread = false;
        private bool stopDriverThread = false;

        private Thread cpuThread;
        private Thread ramThread;
        private Thread driveThread;

        public Form1()
        {
            InitializeComponent();
            LabelCpu.Visible = false;
            LabelRam.Visible = false;
            LabelDriver.Visible = false;    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (label1.Visible == true)
            {
                stopCpuThread = false;
                stopRamThread = false;
                stopDriverThread = false;
                UpdateSystemInfo();

                label1.Visible = false;
                LabelCpu.Visible = true;
                LabelRam.Visible = true;
                LabelDriver.Visible = true;
                button2.Text = "Stop";
            }
            else
            {
                button2.Text = "Start";
                LabelCpu.Visible = false;
                LabelRam.Visible = false;
                LabelDriver.Visible = false;
                label1.Visible = true;
                ThreadStop();
            }

        }

        private void UpdateSystemInfo()
        {
            cpuThread = new Thread(() =>
            {
                var cpuUsage = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                while (!stopCpuThread)
                {
                    string cpuUsageText = $"CPU Usage: {Math.Round(cpuUsage.NextValue(), 1)}%";
                    this.Invoke(new Action(() =>
                    {
                        LabelCpu.Text = cpuUsageText;
                    }));
                    Thread.Sleep(1000);
                }
            });

            ramThread = new Thread(() =>
            {
                var ramCounter = new PerformanceCounter("Memory", "Available MBytes");
                while (!stopRamThread)
                {
                    string ramUsageText = $"Available RAM: {ramCounter.NextValue()} MB";
                    this.Invoke(new Action(() =>
                    {
                        LabelRam.Text = ramUsageText;
                    }));
                    Thread.Sleep(1500);
                }
            });


            driveThread = new Thread(() =>
            {
                var driveCounter = new PerformanceCounter("PhysicalDisk", "% Disk Time", "_Total");
                while (!stopDriverThread)
                {
                    string driverUsageText = $"Disk Time: {Math.Round(driveCounter.NextValue(), 2)}%";
                    this.Invoke(new Action(() =>
                    {
                        LabelDriver.Text = driverUsageText;
                    }));
                    Thread.Sleep(1500);
                }
            });


            cpuThread.Start();
            ramThread.Start();
            driveThread.Start();
        }

        private void ThreadStop()
        {
            stopCpuThread = true;
            stopRamThread = true;
            stopDriverThread = true;

            cpuThread.Join();
            ramThread.Join();
            driveThread.Join();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
