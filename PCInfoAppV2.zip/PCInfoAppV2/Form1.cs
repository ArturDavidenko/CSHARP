using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

namespace PCInfoAppV2
{
    public partial class Form1 : Form
    {
        private object locker = new object();

        private bool stopCpuThread = false;
        private bool stopRamThread = false;
        private bool stopDriverThread = false;

        private Thread cpuThread;
        private Thread ramThread;
        private Thread driveThread;

        static string cpuValue;
        static string ramValue;
        static string driverValue;

        static DateTime currentTime = DateTime.Now;


        // ������� ��� ������������ ����
        private delegate bool EnumWindowsProc(IntPtr hWnd, int lParam);

        // API ������� ��� ������������ ���� ����
        [DllImport("user32.dll")]
        private static extern bool EnumWindows(EnumWindowsProc enumProc, int lParam);

        // API ������� ��� ��������� ��������� ����
        [DllImport("user32.dll")]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        // API ������� ��� �������� ��������� ����
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        static extern bool IsWindowVisible(IntPtr hWnd);

        public Form1()
        {
            InitializeComponent();
            LabelCpu.Visible = false;
            LabelRam.Visible = false;
            LabelDriver.Visible = false;
            button2.Visible = false;

            this.LabelCpu.TextChanged += (sender, e) => {
                cpuValue = LabelCpu.Text;
            };

            this.LabelRam.TextChanged += (sender, e) => {
                ramValue = LabelRam.Text;
            };

            this.LabelDriver.TextChanged += (sender, e) => {
                driverValue = LabelDriver.Text;
            };
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (label1.Visible == true)
            {
                stopCpuThread = false;
                stopRamThread = false;
                stopDriverThread = false;
                UpdateSystemInfo();

                label1.Visible = false;
                LabelCpu.Visible = true;
                LabelRam.Visible = true;
                LabelDriver.Visible = true;
                button2.Visible = true;
                button1.Text = "Stop";
            }
            else
            {
                button1.Text = "Start";
                LabelCpu.Visible = false;
                LabelRam.Visible = false;
                LabelDriver.Visible = false;
                label1.Visible = true;
                button2.Visible = false;
                ThreadStop();
            }
        }

        private void UpdateSystemInfo()
        {
            cpuThread = new Thread(() =>
            {
                var cpuUsage = new PerformanceCounter("Processor", "% Processor Time", "_Total");
                while (!stopCpuThread)
                {
                    string cpuUsageText = $"CPU Usage: {Math.Round(cpuUsage.NextValue(), 1)}%";
                    this.Invoke(new Action(() =>
                    {
                        LabelCpu.Text = cpuUsageText;
                    }));
                    Thread.Sleep(1000);
                }
            });

            ramThread = new Thread(() =>
            {
                var ramCounter = new PerformanceCounter("Memory", "Available MBytes");
                while (!stopRamThread)
                {
                    string ramUsageText = $"Available RAM: {ramCounter.NextValue()} MB";
                    this.Invoke(new Action(() =>
                    {
                        LabelRam.Text = ramUsageText;
                    }));
                    Thread.Sleep(1500);
                }
            });


            driveThread = new Thread(() =>
            {
                var driveCounter = new PerformanceCounter("PhysicalDisk", "% Disk Time", "_Total");
                while (!stopDriverThread)
                {
                    string driverUsageText = $"Disk Time: {Math.Round(driveCounter.NextValue(), 2)}%";
                    this.Invoke(new Action(() =>
                    {
                        LabelDriver.Text = driverUsageText;
                    }));
                    Thread.Sleep(1500);
                }
            });


            cpuThread.Priority = ThreadPriority.Highest;
            ramThread.Priority = ThreadPriority.Highest;
            driveThread.Priority = ThreadPriority.Highest;

            cpuThread.Start();
            ramThread.Start();
            driveThread.Start();
        }

        private void ThreadStop()
        {
            stopCpuThread = true;
            stopRamThread = true;
            stopDriverThread = true;

            cpuThread.Join();
            ramThread.Join();
            driveThread.Join();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lock (locker)
            {
                WriteWindowsToFile("C:\\Users\\User\\Desktop\\LBTU 6 sem\\Programmesanas tehnologijas\\PCInfoApp\\PCInfoAppV2\\file.txt");
            }
        }

        private static string GetWindowText(IntPtr hWnd)
        {
            StringBuilder sb = new StringBuilder(1000);
            GetWindowText(hWnd, sb, sb.Capacity);
            return sb.ToString();
        }

        public static void WriteWindowsToFile(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine("Your System tracer: ");
                EnumWindows(delegate (IntPtr hWnd, int lParam)
                {
                    if (IsWindowVisible(hWnd))
                    {
                        string windowText = GetWindowText(hWnd);
                        if (!string.IsNullOrEmpty(windowText))
                        {
                            writer.WriteLine(currentTime.ToString());
                            writer.WriteLine(windowText);
                        }
                    }
                    return true;
                }, 0);
                writer.WriteLine("-------------------------------");
                writer.WriteLine($"Your PC metric on the moment: ");
                writer.WriteLine($"Your CPU value: {cpuValue}");
                writer.WriteLine($"Your RAM value: {ramValue}");
                writer.WriteLine($"Your Driver value: {driverValue}");
            }
        }
    }


}
