﻿namespace PCInfoAppV2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            LabelCpu = new Label();
            LabelRam = new Label();
            LabelDriver = new Label();
            button1 = new Button();
            button2 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 26F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(234, 9);
            label1.Name = "label1";
            label1.Size = new Size(332, 62);
            label1.TabIndex = 0;
            label1.Text = "PC info tracker";
            label1.Click += label1_Click;
            // 
            // LabelCpu
            // 
            LabelCpu.AutoSize = true;
            LabelCpu.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            LabelCpu.Location = new Point(273, 118);
            LabelCpu.Name = "LabelCpu";
            LabelCpu.Size = new Size(133, 32);
            LabelCpu.TabIndex = 1;
            LabelCpu.Text = "CPU usage:";
            // 
            // LabelRam
            // 
            LabelRam.AutoSize = true;
            LabelRam.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            LabelRam.Location = new Point(273, 194);
            LabelRam.Name = "LabelRam";
            LabelRam.Size = new Size(173, 32);
            LabelRam.TabIndex = 2;
            LabelRam.Text = "Available RAM:";
            // 
            // LabelDriver
            // 
            LabelDriver.AutoSize = true;
            LabelDriver.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            LabelDriver.Location = new Point(273, 282);
            LabelDriver.Name = "LabelDriver";
            LabelDriver.Size = new Size(124, 32);
            LabelDriver.TabIndex = 3;
            LabelDriver.Text = "Disk Time:";
            // 
            // button1
            // 
            button1.Location = new Point(314, 370);
            button1.Name = "button1";
            button1.Size = new Size(168, 50);
            button1.TabIndex = 4;
            button1.Text = "Start";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(548, 370);
            button2.Name = "button2";
            button2.Size = new Size(191, 50);
            button2.TabIndex = 5;
            button2.Text = "Record data in txt file";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(LabelDriver);
            Controls.Add(LabelRam);
            Controls.Add(LabelCpu);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label LabelCpu;
        private Label LabelRam;
        private Label LabelDriver;
        private Button button1;
        private Button button2;
    }
}