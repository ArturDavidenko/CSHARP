﻿



Console.WriteLine("y/x : \t1\t2\t3\t4\t5\t6\t7\t8\t9");
Console.WriteLine("----------------------------------------------------------------------------");

for (int i = 1; i <= 9; i++)
{
    Console.WriteLine(i + "   :   " + i + "\t" + i * 2 + "\t" + i * 3 + "\t" + i * 4 + "\t" + i * 5 + "\t" + i * 6 + "\t" + i * 7 + "\t" + i * 8 + "\t" + i * 9);
}
