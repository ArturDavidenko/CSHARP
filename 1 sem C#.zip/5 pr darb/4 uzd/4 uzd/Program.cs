﻿using System;

namespace _4_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            int m, d, p, l, di;
            Console.WriteLine("1-Kvadrāta perimetra formula");
            Console.WriteLine("2-Kvadrāta laukuma formula");
            Console.WriteLine("3-Kvadrāta diagonāles formula");
            switch (m)
            {
                case 

            }




            Console.Write("Ievadiet formulu: ");



            Console.Write("Ievadiet malu a: ");
            m = int.Parse(Console.ReadLine());
            Console.Write("Izveleties darbibu: ");
            d = int.Parse(Console.ReadLine());
            Console.Write("Kvadrata perimetrs: ");
            p = int.Parse(Console.ReadLine());

              

        }
    }
}
