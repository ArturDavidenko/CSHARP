﻿using System;

namespace _5_pr_darb
{
    class Program
    {
        static void Main(string[] args)
        {
            double x;

            bool end = false;
            do

            {
                Console.WriteLine("ur x: ");
                x = Convert.ToDouble(Console.ReadLine());

                if (x % 2 == 0)
                {
                    x = x / 2;
                    Console.WriteLine($"podelil na 2 ebat:\t" + x);
                }
                else if (x < 0)
                {
                    Console.WriteLine("no -");
                }
                else
                {
                    x = x * 2;
                    Console.WriteLine("prevratil v chetnoje: \t" + x);
                }

                Console.WriteLine("end work ebat?");
                Console.WriteLine("1 - y/ 2 - n");
                string a = Console.ReadLine();

                switch (a)
                {
                    case "1":
                        end = false;
                        Console.WriteLine("ur work end debil!");
                        break;

                    case "2":
                        end = true;
                        break;

                    default:
                        Console.WriteLine("no choose it!");
                        break;
                }

            } while (end != false);
        }
    }
}
