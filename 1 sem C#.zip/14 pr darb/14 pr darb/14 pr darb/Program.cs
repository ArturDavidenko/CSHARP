﻿using System;

namespace _14_pr_darb
{
    class Program
    {
        static void Main(string[] args)
        {
            //1 uzd 
            Random random = new Random();
            int[,] n1_masivs = new int[10, 10];
            for (int i = 0; i < n1_masivs.GetLength(0); i++)
            {
                for (int j = 0; j < n1_masivs.GetLength(1); j++)
                {
                    n1_masivs[i, j] = random.Next(10);
                    Console.Write(n1_masivs[i, j] + "\t");
                }
                Console.WriteLine();
            }       
            int rindas_summa = 0;
            int masiva_summa = 0;
            for (int i = 0; i < n1_masivs.GetLength(0); i++)
            {
                for (int j = 0; j < n1_masivs.GetLength(1); j++)
                {
                    rindas_summa += n1_masivs[i, j];
                }
                Console.WriteLine($"{i + 1}. rindas skaitlu summa ir {rindas_summa}");
                masiva_summa += rindas_summa;
                rindas_summa = 0;
            }

            Console.WriteLine($"Masiva skaitlu summa ir {masiva_summa}");


            //2 uzd 
            int[,] n2_masivs = new int[10, 10];
            for (int i = 0; i < n2_masivs.GetLength(0); i++)
            {
                for (int j = 0; j < n2_masivs.GetLength(1); j++)
                {
                    n2_masivs[i, j] = random.Next(10);
                    Console.Write(n2_masivs[i, j] + "\t");
                }
                Console.WriteLine();
            }

            int kopa_max = int.MinValue;
            int kopa_min = int.MaxValue;
            for (int i = 0; i < n2_masivs.GetLength(0); i++)
            {
                int rinda_max = int.MinValue;
                int rinda_min = int.MaxValue;
                for (int j = 0; j < n2_masivs.GetLength(1); j++)
                {
                    if (n2_masivs[i, j] > rinda_max)
                    {
                        rinda_max = n2_masivs[i, j];
                    }
                    if (n2_masivs[i, j] < rinda_min)
                    {
                        rinda_min = n2_masivs[i, j];
                    }
                }
                Console.WriteLine($"{i + 1}. rindas max vertiba: {rinda_max}, rindas min vertiba: {rinda_min}");
                if (rinda_max > kopa_max)
                {
                    kopa_max = rinda_max;
                }
                if (rinda_min < kopa_min)
                {
                    kopa_min = rinda_min;
                }
            }
            Console.WriteLine($"Visa masiva max vertiba: {kopa_max}, visa masiva min vertiba: {kopa_min}");

            //3 uzd 
            int[,] n3_masivs = new int[10, 10];
            for (int i = 0; i < n3_masivs.GetLength(0); i++)
            {
                for (int j = 0; j < n3_masivs.GetLength(1); j++)
                {
                    n3_masivs[i, j] = random.Next(10);
                    Console.Write(n3_masivs[i, j] + "\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            int temp;
            for (int i = 0; i < n3_masivs.GetLength(0); i++)
            {
                for (int j = 0; j < n3_masivs.GetLength(1); j++)
                {
                    if (i < j)
                    {
                        temp = n3_masivs[i, j];
                        n3_masivs[i, j] = n3_masivs[j, i];
                        n3_masivs[j, i] = temp;
                    }
                    Console.Write(n3_masivs[i, j] + "\t");
                }
                Console.WriteLine();
            }

            //4 uzd 
            int[,] n4_masivs = new int[10, 10];
            for (int i = 0; i < n4_masivs.GetLength(0); i++)
            {
                for (int j = 0; j < n4_masivs.GetLength(1); j++)
                {
                    n4_masivs[i, j] = random.Next(10);
                    Console.Write(n4_masivs[i, j] + "\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine();
            for (int i = 0; i < n4_masivs.GetLength(0); i++)
            {
                for (int j = 0; j < n4_masivs.GetLength(1); j++)
                {
                    if (i < j)
                    {
                        n4_masivs[i, j] = 0;
                    }
                    Console.Write(n4_masivs[i, j] + "\t");
                }
                Console.WriteLine();
            }















        }
    }
}
