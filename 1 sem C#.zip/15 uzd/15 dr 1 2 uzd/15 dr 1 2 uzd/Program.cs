﻿using System;

namespace _15_dr_1_2_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ievadiet rindu skaitu: ");
            int r = Int32.Parse(Console.ReadLine());
            Console.Write("Ievadiet kolonnu skaitu: ");
            int k = Int32.Parse(Console.ReadLine());
            Random rnd = new Random();
            int[,] masivs = new int[r, k];
            int paraskaitli = 0;
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < k; j++)
                {
                    masivs[i, j] = rnd.Next(1, 100);
                    Console.Write($"{masivs[i, j]}\t");
                    if (masivs[i, j] % 2 == 0)
                    {
                        paraskaitli++;
                    }
                }
                Console.WriteLine();
            }
            int procenti = paraskaitli * 100 / (r * k);
            Console.WriteLine($"\n{procenti}% no masīva elementiem ir pāra skaitļi!\n");

            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < k; j++)
                {
                    if (masivs[i, j] % 2 == 0)
                    {
                        Console.Write($"{masivs[i, j] + 1}\t");
                    }
                    else
                    {
                        Console.Write(masivs[i, j] + "\t");
                    }
                }
                Console.WriteLine();
            }


        }
    }
}
