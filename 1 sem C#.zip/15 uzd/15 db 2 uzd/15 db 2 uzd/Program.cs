﻿using System;

namespace _15_db_2_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ievadiet rindu skaitu: ");
            int r = Int32.Parse(Console.ReadLine());
            Console.Write("Ievadiet kolonnu skaitu: ");
            int k = Int32.Parse(Console.ReadLine());
            Random rnd = new Random();
            int[,] masivs = new int[r, k];
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < k; j++)
                {
                    masivs[i, j] = rnd.Next(1, 100);
                    Console.Write($"{masivs[i, j]}\t");
                }
                Console.WriteLine();
            }
            Console.WriteLine("\nKatrs otrais elements = 0");
            bool a1 = true;
            for (int i = 0; i < r; i++)
            {
                for (int j = 0; j < k; j++)
                {
                    if (a1)
                    {
                        Console.Write("0\t");
                        a1 = false;
                    }
                    else
                    {
                        Console.Write($"{masivs[i, j]}\t");
                        a1 = true;
                    }
                }
                Console.WriteLine();
            }
        }
        
    }
}
