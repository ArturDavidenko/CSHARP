﻿using System;

namespace _1_lessons
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("     ****        * * *      *********    *          *      * **          ");
            Console.WriteLine("  *        *     *    *         *        *          *      *   *         ");
            Console.WriteLine("  *        *     *     *        *        *          *      *    *        ");
            Console.WriteLine("  *        *     *    *         *        *          *      *     *       ");
            Console.WriteLine("  * ****** *     *  *           *        *          *      *  * *        ");
            Console.WriteLine("  *        *     * *            *        *          *      * *           ");
            Console.WriteLine("  *        *     *  *           *          *      *        *    *        ");
            Console.WriteLine("  *        *     *    *         *            ****          *      *      ");
            Console.ReadLine();
            Console.WriteLine("Davidenko");
            Console.ReadLine();
            Console.WriteLine("si");
            Console.ReadLine();
            Console.WriteLine("man");
            Console.ReadLine();
            Console.WriteLine();
            Console.ReadLine();
            Console.WriteLine("darba");
            Console.ReadLine();
        }
    }
}
