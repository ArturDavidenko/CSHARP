﻿



Console.Write("Ievadiet noguldijuma summu: ");
double sum = Convert.ToDouble(Console.ReadLine());
Console.Write("Ievadiet noduldijuma ilgumu(gadu skaitu): ");
int ilg = Convert.ToInt32(Console.ReadLine());
Console.Write("Ievadiet gada % likmi: ");
double lik = Convert.ToDouble(Console.ReadLine());
for (int i = 1; i <= ilg; i++)
{
    sum = sum + (sum * lik);
    Console.WriteLine($"Summa pec {i} gada ir {Math.Round(sum,2)}" );

}
//3 uzd 

Console.WriteLine("y/x : \t1\t2\t3\t4\t5\t6\t7\t8\t9");
Console.WriteLine("----------------------------------");
    for (int i = 1; i < length; i++)
{

}

