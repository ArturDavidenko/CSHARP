﻿using System;

namespace _2_uzd_2_popitka
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Cik reizes parbaudit skaitlus? ");
            int reizes = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < reizes; i++)
            {
                Console.Write("Ievadiet skaitli: ");
                int skaitlis = Convert.ToInt32(Console.ReadLine());
                if (skaitlis % 3 == 0)
                {
                    Console.WriteLine("Skaitlis dalas ar 3 bez atlikuma!");
                }
                else
                {
                    Console.WriteLine("Skaitlis NEdalas ar 3 bez atlikuma!");
                }
            }
    }
}
