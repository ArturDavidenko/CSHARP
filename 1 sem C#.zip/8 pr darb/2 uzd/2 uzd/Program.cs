﻿using System;

namespace _2_uzd
{
    class Program
    {
        static void Main(string[] args)
        {



        }
    }
}
