﻿using System;

namespace _8_pr_darb
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                Console.WriteLine("Ievadies skaitli no 1 lidz 5 vai IZIET lai beigtu darbibu ");
                string i = Convert.ToString(Console.ReadLine());
                switch (i)
                {
                    case "1":
                        Console.WriteLine("Viens");
                        break;
                    case "2":
                        Console.WriteLine("Divi");
                        break;
                    case "3":
                        Console.WriteLine("Tris");
                        break;
                    case "4":
                        Console.WriteLine("Cetri");
                        break;
                    case "5":
                        Console.WriteLine("Pieci");
                        break;
                    case "IZIET":
                        Console.WriteLine("PRAGRAMMA BEIDZ DARBIBU");
                        return;
                    default:
                        Console.WriteLine("Skaitlis nav robezas no 1 lidz 5");
                        break;
                }
            } while (true);

            // 2 uzd 

            Console.Write("Cik reizes parbaudit skaitlus? ");
            int rez = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < rez; i++)
            {
                Console.Write("Ievadiet skaitli: ");
                int skaitlis = Convert.ToInt32(Console.ReadLine());
                if (skaitlis % 3 == 0)
                {
                    Console.WriteLine("Skaitlis dalas ar 3 bez atlikuma!");
                }
                else
                {
                    Console.WriteLine("Skaitlis NEdalas ar 3 bez atlikuma!");
                }

            }
        }
}
