﻿using System;

namespace _4_pr_darbs_1_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            Console.Write("Ievadiet skaitli X : > ");
            x = Convert.ToInt32(Console.ReadLine());
            for (x = x + 1; x <= 10; x++)

            Console.WriteLine("inkramentēšanas rezultats: " + x);

            Console.Write("Ievadiet skaitli X : > ");
            x = Convert.ToInt32(Console.ReadLine());
            for (x = x - 1; x > -1; x--)

            Console.WriteLine("inkramentēšanas rezultats: " + x);

            Console.WriteLine("ur y was in kvadrat");
            Console.WriteLine("ur y: ");

            double y = Convert.ToDouble(Console.ReadLine());

            y = Math.Pow(y, 2);
            Console.WriteLine($"ur y in kvadrat {y}");
            
            

        }
    }
}
