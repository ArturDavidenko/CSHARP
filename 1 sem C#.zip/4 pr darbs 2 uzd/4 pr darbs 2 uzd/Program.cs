﻿using System;

namespace _4_pr_darbs_2_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            char[] m;
            m = new char[] { '@', '6', 'A', 'C', '9', '5', '4', 'B', 'B', '<', '7', '9', '2', ';', '7', '<', '@', '6', '2', '<', };
            int count = 0;
            for (int i = 0; i < m.Length; i++)
            {
                Console.WriteLine($"mas[{0}] = {1}", i + 1, m[i]);
            }
            Console.WriteLine();
            Console.Write("Ievadiet simbolu: ");
            char simbols = Convert.ToChar(Console.ReadLine());

            for (int i = 0; i < m.Length; i++)
            {
                if (simbols == m[i])
                {
                    continue;
                }
                Console.WriteLine($"mas[{0}] = {1}", i + 1, m[i]);
            }
        }
    }
}
