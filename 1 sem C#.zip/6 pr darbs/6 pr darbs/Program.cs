﻿using System;

namespace _6_Praktiskais_darbs
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ievadiet noguldijuma summu: ");
            int sum = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ievadiet noduldijuma ilgumu(gadu skaitu): ");
            int ilg = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Ievadiet gada % likmi: ");
            int lik = Int32.Parse(Console.ReadLine());
            for (int i = 1; i < sum; i++)
            {
                sum = sum * lik;
                Console.WriteLine($"Summa pec " + ilg "gada ir" + sum);

            }

        }
    }
}
