﻿using System;

namespace _7_pr_darb
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ievadiet taisnstura garumu:");
            int i = Convert.ToInt32(Console.ReadLine());
            int x = 1;
            while (i-- != 0)
            {
                int y = x;
                while (y-- != 0)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
                x = x + 1;
            }
            //2uzd
            string a, parole = "Arturs";
            Console.Write("Ievadiet paroli: ");
            a = Console.ReadLine();
            while (a != parole)
            {
                Console.WriteLine("Parole ir ievadita nepareizi!");
                Console.Write("Ievadiet paroli: ");
                a = Console.ReadLine();
            }
            Console.WriteLine("Parole ir ievadita pareizi!");

            //3uzd 
            Console.Write("Ievadiet skaitli R: ");
            int r = Convert.ToInt32(Console.ReadLine());
            Console.Write("Ievadiet pirmo skaitli: ");
            int skaitlis = Convert.ToInt32(Console.ReadLine());
            int i = 0;
            int j = 1;
            int reizinajums, reizinatajs;

            do
            {
                Console.Write("Reiz[{0}] = {1}*", i, skaitlis);
                reizinatajs = Convert.ToInt32(Console.ReadLine());
                reizinajums = skaitlis * reizinatajs;
                i++;
                do
                {
                    Console.Write("Reiz[{0}] = {1}*", j, reizinajums);
                    reizinatajs = Convert.ToInt32(Console.ReadLine());
                    reizinajums = reizinajums * reizinatajs;
                    j++;
                } while (j < r);
                Console.WriteLine("Reiz[{0}] = {1}", r, reizinajums);
            } while (i == 0);


        }
    }
}
