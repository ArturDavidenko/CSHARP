﻿using System;

namespace _12_pr_1_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            int minElements = 10;
            int maxElements = 100;
            Console.Write("Ievadiet pirma masiva izmeru: ");
            int masivs1izmers = Convert.ToInt32(Console.ReadLine());
            Console.Write("Ievadiet otra masiva izmeru: ");
            int masivs2izmers = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("pirmais\t" + "otrais\t");
            Random rnd = new Random();
            int[] masivs1 = new int[masivs1izmers];
            int[] masivs2 = new int[masivs2izmers];
            for (int i = 0; i < masivs1izmers; i++)
            {
                masivs1[i] = rnd.Next(minElements, maxElements);
            }
            for (int i = 0; i < masivs2izmers; i++)
            {
                masivs2[i] = rnd.Next(minElements, maxElements);
            }
            if (masivs1izmers > masivs2izmers)
            {
                for (int i = 0; i < masivs2izmers; i++)
                {
                    Console.WriteLine(masivs1[i] + "\t" + masivs2[i] + "\t");
                }
                for (int i = masivs2izmers; i < masivs1izmers; i++)
                {
                    Console.WriteLine(masivs1[i] + "\t");
                }
            }
            else
            {
                for (int i = 0; i < masivs1izmers; i++)
                {
                    Console.WriteLine(masivs1[i] + "\t" + masivs2[i] + "\t");
                }
                for (int i = masivs1izmers; i < masivs2izmers; i++)
                {
                    Console.WriteLine("\t" + masivs2[i] + "\t");
                }
            }
            int max1 = masivs1.Max();
            int min1 = masivs1.Min();
            int max2 = masivs2.Max();
            int min2 = masivs2.Min();
            if (min1 == min2)
            {
                Console.WriteLine("Mazakais skaitlis ir gan pirma, gan otra maisva un ir vienads ar {0}", min1);
            }
            else if (min1 < min2)
            {
                Console.WriteLine("Mazakais skaitlis ir no pirma masiva un ir vienads ar {0}", min1);
            }
            else
            {
                Console.WriteLine("Mazakais skaitlis ir no otra masiva un ir vienads ar {0}", min2);
            }
            if (max1 == max2)
            {
                Console.WriteLine("Lielakais skaitlis ir gan pirma, gan otra maisva un ir vienads ar {0}", max1);
            }
            else if (max1 > max2)
            {
                Console.WriteLine("Lielakais skaitlis ir no pirma masiva un ir vienads ar {0}", max1);
            }
            else
            {
                Console.WriteLine("Lielakais skaitlis ir no otra masiva un ir vienads ar {0}", max2);
            }
        }
    }
}
