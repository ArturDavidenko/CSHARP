﻿using System;

namespace _10_pr_darb
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] a = new string[10];
            int i;

            for (i = 0; i < 10; i++)
            {
                Console.Write("Ievadiet {0} masiva vertibu: ", i + 1);
                a[i] = Convert.ToString(Console.ReadLine());
            }

            for (i = 0; i < 10; i++)
            {
                Console.WriteLine("Masiva {0} vertiba ir {1} ", i + 1, a[i]);
            }
            Console.WriteLine();
            Console.Write("Apvienotais masivs: ");
            for (int j = 0; j < 10; j++)
            {
                Console.Write(a[j]);
            }
            Console.ReadLine();
        }
    }
}
