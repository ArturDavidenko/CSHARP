﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            int y;
            Console.WriteLine("Ievadiet divus veselus skaitlus");
            Console.Write("Ievadiet veselu skaitli x : > ");
            x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Ievadiet veselu skaitli y : > ");
            y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"X + Y = {x + y}");
            Console.WriteLine($"X - Y = {x - y}");
            Console.WriteLine($"X * Y = {x * y}");
            Console.WriteLine($"X / Y = {x / y}");
            Console.WriteLine($"X % Y = {x % y}");
            Console.WriteLine($"X / Y = {(float)x / y}");
            Console.WriteLine($"X^2 + Y^2 = {Math.Pow(x, 2) + Math.Pow(y, 2)}");

        }
    }
}