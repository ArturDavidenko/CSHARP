﻿using System;
using System.Data.SqlClient;

namespace _2_uzd_DB
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = "Server=(localdb)????????????; Database=csharpdb; Trusted_Connection=True; MultipleActiveResultSets=True;";
            string selectInput = "SELECT * FROM Users";

            SqlConnection connection = new SqlConnection(connectionString);

            SqlCommand sqlSelect = new SqlCommand(selectInput, connection);

            bool EndWork = true;

            while (EndWork)
            {
                Console.WriteLine("Choose ur step: ");
                Console.WriteLine("1 - Show data from database");
                Console.WriteLine("2 - Insert data into database");
                Console.WriteLine("3 - Remove user from database");
                Console.WriteLine("4 - Exit");
                Console.WriteLine("Ur choose: ");
                int choose = Convert.ToInt32(Console.ReadLine());

                switch (choose)
                {

                    case 1:
                        try
                        {
                            connection.Open();
                            var reader = sqlSelect.ExecuteReader();

                            if (reader.HasRows)
                            {
                                Console.WriteLine("{0} \t{1} \t{2} \t{3} \t{4} \t{5} \t{6} \t{7}",
                                    reader.GetName(0),
                                    reader.GetName(1),
                                    reader.GetName(2),
                                    reader.GetName(3),
                                    reader.GetName(4),
                                    reader.GetName(5),
                                    reader.GetName(6),
                                    reader.GetName(7));

                                while (reader.Read())
                                {
                                    var id = reader.GetValue(0);
                                    var name = reader.GetValue(1);
                                    var lastname = reader.GetValue(2);
                                    var status = reader.GetValue(3);
                                    var info = reader.GetValue(4);
                                    var age = reader.GetValue(5);
                                    var profession = reader.GetValue(6);
                                    var hasChildren = reader.GetValue(7);


                                    Console.WriteLine("{0} \t{1} \t{2} \t{3} \t{4} \t{5} \t{6} \t{7}",
                                        id,
                                        name,
                                        lastname,
                                        status,
                                        info,
                                        age,
                                        profession,
                                        hasChildren);
                                }
                            }


                        }
                        catch (SqlException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        finally
                        {
                            connection.Close();
                        }
                        Console.ReadKey();
                        Console.Clear();
                    break;

                    case 2:
                        try
                        {
                            Console.WriteLine("Write user name: ");
                            string userNameInput = Console.ReadLine();
                            Console.WriteLine("Write user lastname: ");
                            string userLastnameInput = Console.ReadLine();
                            Console.WriteLine("Write user status: ");
                            string userStatusInput = Console.ReadLine();
                            Console.WriteLine("Write user info: ");
                            string userInfoInput = Console.ReadLine();
                            Console.WriteLine("Write user age: ");
                            string userAgeInput = Console.ReadLine();
                            Console.WriteLine("Write user profession: ");
                            string userProfessionInput = Console.ReadLine();
                            Console.WriteLine("Write user have children y/n ? : ");
                            string userIsChildrenInput = Console.ReadLine();
                            bool userChildren = false;

                            if (userIsChildrenInput == "y")
                            { 
                                userChildren = true;
                            }
                            else if (userIsChildrenInput == "n")
                            {
                                userChildren = false;
                            }

                            connection.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = connection;
                            cmd.CommandText = @"INSERT INTO Users (name, lastname, status, info, age, profession, ischildren) 
                            VALUES (@userName, @userLastname, @userStatus, @userInfo, @userAge, @userProfession, @userIschildren)";

                            SqlParameter nameParametr = new SqlParameter("@userName", userNameInput);
                            cmd.Parameters.Add(nameParametr);
                            SqlParameter lastnameParametr = new SqlParameter("@userLastname", userLastnameInput);
                            cmd.Parameters.Add(lastnameParametr);
                            SqlParameter statusParametr = new SqlParameter("@userStatus", userStatusInput);
                            cmd.Parameters.Add(statusParametr);
                            SqlParameter infoParametr = new SqlParameter("@userInfo", userInfoInput);
                            cmd.Parameters.Add(infoParametr);
                            SqlParameter ageParametr = new SqlParameter("@userAge", userAgeInput);
                            cmd.Parameters.Add(ageParametr);
                            SqlParameter professionParametr = new SqlParameter("@userProfession", userProfessionInput);
                            cmd.Parameters.Add(professionParametr);
                            SqlParameter isChildrenParametr = new SqlParameter("@userIschildren", userIsChildrenInput);
                            cmd.Parameters.Add(isChildrenParametr);

                            cmd.ExecuteNonQuery();
                            Console.WriteLine($"New user {userNameInput} is ready!");
                            Console.ReadKey();
                        }
                        catch (SqlException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        finally
                        {
                            connection.Close();
                        }
                        Console.ReadKey();
                        Console.Clear();
                        break;

                    case 3:
                        string userToDelete;

                        Console.WriteLine("Write id of user to delete: ");
                        userToDelete = Console.ReadLine();

                        connection.Open();
                        try
                        {
                            SqlCommand command = new SqlCommand("DELETE FROM Users WHERE id = '" + userToDelete + "'", connection);
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                        catch (SqlException ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        Console.WriteLine($"User with id {userToDelete} is deleted!");
                        Console.ReadKey();
                        break;

                    case 4:
                        Console.WriteLine("Work is END!");
                        EndWork = false;
                        break;
                    default:
                        Console.WriteLine("This choose is not abviable!");
                        Console.WriteLine();
                        break;
                }
            } 
        }
    }
}
