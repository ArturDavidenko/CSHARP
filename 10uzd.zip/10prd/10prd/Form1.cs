﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Data;
using System.Windows.Forms;

namespace _10prd
{
    public partial class Form1 : Form
    {

        Form3 form3;
        private const string ConnectionString = "Host = localhost; Username = artur; password=12345; Database = csharp";
        private readonly NpgsqlDataAdapter _houseAdapter = new();
        private readonly NpgsqlDataAdapter _ownerAdapter = new();
        private readonly NpgsqlDataAdapter _projectAdapter = new();
        private DataSet _ds = new("Task");
        DataTable dtSHouses = new("Houses");
        DataTable dtOwners = new("Owners");
        DataTable dtProjects = new("Projects");

        public Form1()
        {
            InitializeComponent();
            IsMdiContainer = true;

            _ds.Tables.Add(dtSHouses);
            _ds.Tables.Add(dtOwners);
            _ds.Tables.Add(dtProjects);

            const string firstSql = "SELECT * FROM project";
            const string secondSql = "SELECT * FROM owner";
            const string thirdSql = "SELECT * FROM house";
            var connection = new NpgsqlConnection(ConnectionString);

            try
            {
                var command1 = new NpgsqlCommand(firstSql, connection);
                _projectAdapter.SelectCommand = command1;
                _projectAdapter.Fill(dtProjects);

                var command2 = new NpgsqlCommand(secondSql, connection);
                _ownerAdapter.SelectCommand = command2;
                _ownerAdapter.Fill(dtOwners);

                var command3 = new NpgsqlCommand(thirdSql, connection);
                _houseAdapter.SelectCommand = command3;
                _houseAdapter.Fill(dtSHouses);
            }
            catch (Exception ex)
            {
                throw;
            }


            //DataRelation - Представляет отношение "родительский-дочерний объект" между двумя объектами DataTable. FK
            _ds.Relations.Add(new DataRelation("owner_relation",
                _ds.Tables["Owners"].Columns["id"],
                _ds.Tables["Houses"].Columns["owner_id"],
                false));

            _ds.Relations.Add(new DataRelation("project_rel",
                _ds.Tables["Projects"].Columns["id"],
                _ds.Tables["Houses"].Columns["project_id"],
                false));

            var f2 = new Form2(_ds);
            f2.MdiParent = this;
            f2.Show();

            //var f3 = new Form3(dtProjects);
            //f3.MdiParent = this;
            //f3.Show();

            form3 = new Form3(dtProjects);
            form3.MdiParent = this;
            form3.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            _ds.Tables[0].Clear();
            _ds.Tables[1].Clear();
            _ds.Tables[2].Clear();
            //_ds.EnforceConstraints = false;

            _projectAdapter.Fill(dtProjects);
            _ownerAdapter.Fill(dtOwners);
            _houseAdapter.Fill(dtSHouses);

            form3.bs.AddNew();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var connection = new NpgsqlConnection(ConnectionString);

            #region projects

            var projectsInsertCommand = new NpgsqlCommand("INSERT INTO project (title) VALUES (@title)", connection);
            projectsInsertCommand.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));

            var projectsUpdateCommand =
                new NpgsqlCommand(
                    "UPDATE project SET title = @title WHERE id = @id",
                    connection);
            projectsUpdateCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            projectsUpdateCommand.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));

            var projectsDeleteCommand = new NpgsqlCommand("DELETE FROM project WHERE id=@id", connection);
            projectsDeleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            #endregion

            #region owners

            var ownersInsertCommands = new NpgsqlCommand("INSERT INTO owner (name, surname) VALUES (@name, @surname)", connection);
            ownersInsertCommands.Parameters.Add(new NpgsqlParameter("@name", NpgsqlDbType.Varchar, 12, "name"));
            ownersInsertCommands.Parameters.Add(new NpgsqlParameter("@surname", NpgsqlDbType.Varchar, 12, "surname"));

            var ownersUpdateCommand = new NpgsqlCommand("UPDATE owner SET name = @name, surname = @surname WHERE id = @id", connection);
            ownersUpdateCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            ownersUpdateCommand.Parameters.Add(new NpgsqlParameter("@name", NpgsqlDbType.Varchar, 12, "name"));
            ownersUpdateCommand.Parameters.Add(new NpgsqlParameter("@surname", NpgsqlDbType.Varchar, 12, "surname"));

            var ownersDeleteCommand = new NpgsqlCommand("DELETE FROM owner WHERE id=@id", connection);
            ownersDeleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            #endregion

            #region houses

            var housesInsertCommand = new NpgsqlCommand("INSERT INTO house (address, area, owner_id, project_id) VALUES (@address, @area, @owner_id, @project_id)", connection);
            housesInsertCommand.Parameters.Add(new NpgsqlParameter("@address", NpgsqlDbType.Varchar, 12, "address"));
            housesInsertCommand.Parameters.Add(new NpgsqlParameter("@area", NpgsqlDbType.Integer, 12, "area"));
            housesInsertCommand.Parameters.Add(new NpgsqlParameter("@owner_id", NpgsqlDbType.Integer, 12, "owner_id"));
            housesInsertCommand.Parameters.Add(new NpgsqlParameter("@project_id", NpgsqlDbType.Integer, 12, "project_id"));

            var housesUpdateCommand = new NpgsqlCommand("UPDATE house SET address = @address, area = @area, owner_id = @owner_id, project_id = @project_id WHERE id = @id", connection);
            housesUpdateCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            housesUpdateCommand.Parameters.Add(new NpgsqlParameter("@address", NpgsqlDbType.Varchar, 12, "address"));
            housesUpdateCommand.Parameters.Add(new NpgsqlParameter("@area", NpgsqlDbType.Integer, 12, "area"));
            housesUpdateCommand.Parameters.Add(new NpgsqlParameter("@owner_id", NpgsqlDbType.Integer, 12, "owner_id"));
            housesUpdateCommand.Parameters.Add(new NpgsqlParameter("@project_id", NpgsqlDbType.Integer, 12, "project_id"));

            var housesDeleteCommand = new NpgsqlCommand("DELETE FROM house WHERE id=@id", connection);
            housesDeleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            #endregion

            _projectAdapter.InsertCommand = projectsInsertCommand;
            _projectAdapter.UpdateCommand = projectsUpdateCommand;
            _projectAdapter.DeleteCommand = projectsDeleteCommand;
            _projectAdapter.Update(dtProjects);

            _ownerAdapter.InsertCommand = ownersInsertCommands;
            _ownerAdapter.UpdateCommand = ownersUpdateCommand;
            _ownerAdapter.DeleteCommand = ownersDeleteCommand;
            _ownerAdapter.Update(dtOwners);

            _houseAdapter.InsertCommand = housesInsertCommand;
            _houseAdapter.UpdateCommand = housesUpdateCommand;
            _houseAdapter.DeleteCommand = housesDeleteCommand;
            _houseAdapter.Update(dtSHouses);
        }
    }
}
