﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10prd
{
    public partial class Form2 : Form
    {
        BindingSource bs;
        public Form2(DataSet ds)
        {
            InitializeComponent();
            bs = new BindingSource();
            bs.DataSource = ds;

            projectsView.DataSource = ds.Tables[2];  // project
            projectsView.Columns[0].Visible = false;

            ownersView.DataSource = ds.Tables[1]; // owners
            ownersView.Columns[0].Visible = false;

            housesView.DataSource = ds.Tables[0];  //house
            housesView.Columns[0].Visible = false;
            housesView.Columns[3].Visible = false;
            housesView.Columns[4].Visible = false;

            var cbOwner = new DataGridViewComboBoxColumn()
            {
                DataSource = ds.Tables[1],
                HeaderText = "Owner",
                DisplayMember = "name",
                ValueMember = "id",
                DataPropertyName = "id"
            };
            ownersView.Columns[0].Visible = false;
            housesView.Columns.Insert(5, cbOwner);

            var cbProject = new DataGridViewComboBoxColumn()
            {
                DataSource = ds.Tables[2],
                HeaderText = "Project",
                DisplayMember = "title",
                ValueMember = "id",
                DataPropertyName = "id"
            };
            housesView.Columns.Insert(6, cbProject);
        }
    }
}
