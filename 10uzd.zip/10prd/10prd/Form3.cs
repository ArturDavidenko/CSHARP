﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _10prd
{
    public partial class Form3 : Form
    {
        public BindingSource bs;

        public Form3(DataTable dt)
        {
            InitializeComponent();
            bs = new BindingSource();
            bs.DataSource = dt;
            bs.AddNew();
            textBox1.DataBindings.Add("Text", bs, "Title");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            bs.AddNew();
        }
    }
}
