﻿
namespace _10prd
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.projectsView = new System.Windows.Forms.DataGridView();
            this.ownersView = new System.Windows.Forms.DataGridView();
            this.housesView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.projectsView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ownersView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.housesView)).BeginInit();
            this.SuspendLayout();
            // 
            // projectsView
            // 
            this.projectsView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.projectsView.Location = new System.Drawing.Point(69, 65);
            this.projectsView.Name = "projectsView";
            this.projectsView.RowTemplate.Height = 25;
            this.projectsView.Size = new System.Drawing.Size(454, 150);
            this.projectsView.TabIndex = 0;
            // 
            // ownersView
            // 
            this.ownersView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ownersView.Location = new System.Drawing.Point(769, 65);
            this.ownersView.Name = "ownersView";
            this.ownersView.RowTemplate.Height = 25;
            this.ownersView.Size = new System.Drawing.Size(416, 150);
            this.ownersView.TabIndex = 1;
            // 
            // housesView
            // 
            this.housesView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.housesView.Location = new System.Drawing.Point(69, 293);
            this.housesView.Name = "housesView";
            this.housesView.RowTemplate.Height = 25;
            this.housesView.Size = new System.Drawing.Size(1116, 339);
            this.housesView.TabIndex = 2;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1387, 723);
            this.Controls.Add(this.housesView);
            this.Controls.Add(this.ownersView);
            this.Controls.Add(this.projectsView);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.projectsView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ownersView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.housesView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView projectsView;
        private System.Windows.Forms.DataGridView ownersView;
        private System.Windows.Forms.DataGridView housesView;
    }
}