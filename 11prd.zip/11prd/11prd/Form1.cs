﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _11prd
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection conn;
        public NpgsqlDataAdapter katAdapt;
        public NpgsqlDataAdapter _categoryAdapter = new();
        public NpgsqlDataAdapter _productsAdapter = new();
        public DataTable categories;
        public int rowIndex;
        DataTable products;
        public int current_node;
        private const string ConnectionString = "Host = localhost; Username = artur; password=12345; Database = csharp11";


        public Form1()
        {
            InitializeComponent();


            //drīkst mainīt TreeView mezglu tekstu
            treeView1.LabelEdit = true;
            //---
            //Izveidot conekciju conn
            conn = new NpgsqlConnection(ConnectionString);
            //----
            categories = new DataTable();
            //izveidot DataTable colonnas
            //kategorijas1 = new DataTable();
            //izveidot DataTable colonnas
            products = new DataTable();
            //izveidot DataTable colonnas
            //dataGridView1.DataSource = products;
            SubLevel(0, null); //Funkcija, kura izveido TreeView struktūru
        }

        public void SubLevel(int parentid, TreeNode parentNode)
        {
            var selectCommand = new NpgsqlCommand("SELECT id, title as name FROM Categories WHERE category_id = @parent_id", conn);

            selectCommand.Parameters.Add("@parent_id", NpgsqlDbType.Integer).Value = parentid;
            var da = new NpgsqlDataAdapter(selectCommand);
            da.SelectCommand = selectCommand;
            var dt = new DataTable();
            da.Fill(dt);

            if (parentid == 0)
            {
                CreateNodes(dt, treeView1.Nodes);
            }
            else
            {
                CreateNodes(dt, parentNode.Nodes);
            }
        }

        public void CreateNodes(DataTable dt, TreeNodeCollection nodes)
        {
            foreach (DataRow dr1 in dt.Rows)
            {
                var treeNode = new TreeNode
                {
                    Text = dr1["name"].ToString(),
                    Name = dr1["id"].ToString()
                };
                nodes.Add(treeNode);
                SubLevel(Convert.ToInt32(treeNode.Name), treeNode);
            }
        }

        private void TreeView1_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (e.Node.Name != "")
            {
                var treeNode = new TreeNode
                {
                    Text = "new"
                };
                e.Node.Nodes.Add(treeNode);
            }
        }

        private void TreeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            int y = 0;
            if (e.Node.Name != "")
            {
                //Ja mezglam ir nosaukums ( mezgls ir ierakstīts datu bāzē), tiek izpildīta funkcija dgv_select() , kura kā
                // parametru saņem mezgla vārdu(kategorijas ID);
                y = Convert.ToInt32(e.Node.Name);
            }
            Dgv_select(y);
        }

        public void Dgv_select(int e)
        {
            //tiek aizpildīts DataGridView elements
            if (e.ToString() != "")
            {
                products = new DataTable();
                _productsAdapter = new NpgsqlDataAdapter();
                var selectProducts = new NpgsqlCommand($"SELECT * FROM products WHERE category_id = {e}", conn);  //where category_id = ?
                selectProducts.Parameters.Add("@category_id", NpgsqlDbType.Integer).Value = e;
                _productsAdapter.SelectCommand = selectProducts;
                _productsAdapter.Fill(products);
                dataGridView1.DataSource = products;
            }
            //Label elementa tiek attēlots kategorijas apraksts
            var selectDescription = new NpgsqlCommand("Select id, description from categories WHERE NOT(description IS NULL)", conn);

            conn.Open();
            NpgsqlDataReader datareaderapraksts = selectDescription.ExecuteReader();

            string textboxString = "";
            while (datareaderapraksts.Read())
            {
                if (e.ToString() != "" && datareaderapraksts.GetInt32(0) == e)
                {
                    textboxString = datareaderapraksts.GetString(1);
                }
            }

            conn.Close();
            label1.Text = textboxString;
            current_node = e; // cur_node tiek piešķirts aktīvā mezgla vārds ( kategorijas ID)
        }


        private void TreeView1_AfterLabelEdit(object sender, NodeLabelEditEventArgs e)
        {
            if (e.Label != null)
            {
                e.Node.Text = e.Label;
            }
            
            // select
            var selectCategories = new NpgsqlCommand("SELECT * FROM Categories", conn);
            //izveidot NpgsqlCommand comandas: select, insert, delete un update.
            //Piešķirt komandas adapreta komandām(katAdapt1.SelectCommand,
            //katAdapt1.InsertCommand, katAdapt1.DeleteCommand, katAdapt1.UpdateCommand).

            // insert
            var insertCategory = new NpgsqlCommand("INSERT INTO Categories (title, description, category_id) VALUES (@title, @description, category_id)", conn);
            insertCategory.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 50, "title"));
            insertCategory.Parameters.Add(new NpgsqlParameter("@description", NpgsqlDbType.Varchar, 255, "description"));
            insertCategory.Parameters.Add(new NpgsqlParameter("@category_id", NpgsqlDbType.Integer, 12, "category_id"));

            // update
            var updateCategory = new NpgsqlCommand("UPDATE Categories SET title = @title, description = @description, category_id = @category_id WHERE id = @id", conn);
            updateCategory.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            updateCategory.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 50, "title"));
            updateCategory.Parameters.Add(new NpgsqlParameter("@description", NpgsqlDbType.Varchar, 255, "description"));
            updateCategory.Parameters.Add(new NpgsqlParameter("@category_id", NpgsqlDbType.Integer, 12, "category_id"));

            //delete
            var deleteCategory = new NpgsqlCommand("DELETE FROM Categories WHERE id = @id");
            deleteCategory.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            _categoryAdapter.SelectCommand = selectCategories;
            _categoryAdapter.InsertCommand = insertCategory;
            _categoryAdapter.UpdateCommand = updateCategory;
            _categoryAdapter.DeleteCommand = deleteCategory;

            _categoryAdapter.Fill(categories);
            int i = 0;
            int t = -1;
            foreach (DataRow dr in categories.Rows)
            {
                if (dr[0].ToString() == e.Node.Name)
                {
                    t = i;
                }
                i++;
            }
            if (t != -1)
            {
                categories.Rows[t]["title"] = e.Node.Text.ToString();
                categories.Rows[t]["description"] = textBox1.Text.ToString();
            }
            else
            {
                DataRow dr1 = categories.NewRow();
                dr1["id"] = 0;
                dr1["title"] = e.Node.Text.ToString();
                dr1["description"] = textBox1.Text.ToString();
                dr1["category_id"] = Convert.ToInt32(e.Node.Parent.Name);

                categories.Rows.Add(dr1);
            }
            _categoryAdapter.Update(categories);
            textBox1.Text = "";
        }

        private void Save_Click(object sender, EventArgs e)
        {
            var insertProduct = new NpgsqlCommand("INSERT INTO Products (title, price, category_id) VALUES (@title, @price, @category_id)", conn);
            insertProduct.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 50, "title"));
            insertProduct.Parameters.Add(new NpgsqlParameter("@price", NpgsqlDbType.Numeric, 12, "price"));
            insertProduct.Parameters.Add(new NpgsqlParameter("@category_id", NpgsqlDbType.Integer, 12, "category_id"));

            // update
            var updateProduct = new NpgsqlCommand("UPDATE Products SET title = @title, price = @price, category_id = @category_id WHERE id = @id", conn);
            updateProduct.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            updateProduct.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 50, "title"));
            updateProduct.Parameters.Add(new NpgsqlParameter("@price", NpgsqlDbType.Numeric, 12, "price"));
            updateProduct.Parameters.Add(new NpgsqlParameter("@category_id", NpgsqlDbType.Integer, 12, "category_id"));

            //delete
            var deleteProduct = new NpgsqlCommand("DELETE FROM Products WHERE id = @id");
            deleteProduct.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            _productsAdapter.InsertCommand = insertProduct;
            _productsAdapter.UpdateCommand = updateProduct;
            _productsAdapter.DeleteCommand = deleteProduct;

            _productsAdapter.Update(products);
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            int rc = dataGridView1.Rows.Count - 1;
            if (rc > 0)
                dataGridView1.Rows[rc].Cells[3].Value = current_node;
            else
                dataGridView1.Rows[0].Cells[3].Value = current_node;
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}
