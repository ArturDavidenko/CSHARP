﻿using Npgsql;
using System;
using System.Data;
using System.Windows.Forms;

namespace _8prd
{
    public partial class Form1 : Form
    {
        private const string ConnectionString = "Host = localhost; Username = artur; password=12345; Database = students";
        private readonly NpgsqlDataAdapter _adapter = new();
        private static readonly DataTable Dt = new();

        //private static readonly NpgsqlConnection Connection = new(ConnectionString);
        public Form1()
        {
            InitializeComponent();
            var connection = new NpgsqlConnection(ConnectionString);
            var selectCommand = new NpgsqlCommand("SELECT * FROM student", connection);

            _adapter.SelectCommand = selectCommand;

            DataTable dt = new DataTable();
       
            _adapter.Fill(dt);
            listBox1.DataSource = dt;
            listBox1.DisplayMember = "name";

            listBox2.DataSource = dt;
            listBox2.DisplayMember = "surname";

            dataGridView1.DataSource = dt;

            // CurrencyManager - получает привязку и задает CurrencyManager его положение.
            CurrencyManager cm = (CurrencyManager)this.BindingContext[dt];
            int rowIndex = (int)cm.Position;
            textBox1.Text = rowIndex.ToString();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != "")
                {
                    int rowIndex = int.Parse(textBox1.Text);
                    if (rowIndex > listBox1.Items.Count-1 || rowIndex < 0)  //rowIndex > 4 || rowIndex < 0
                    {
                        throw new FormatException();
                    }

                    CurrencyManager cm =
                        (CurrencyManager)this.BindingContext[listBox1.DataSource];
                    cm.Position = rowIndex;
                }
            }
            catch (FormatException ex)
            {
                MessageBox.Show($"Laukā norādītai vērtībai ir jābūt veselam skaitlim robežās no 0 līdz {listBox1.Items.Count-1}");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            CurrencyManager cm =
                (CurrencyManager)this.BindingContext[listBox1.DataSource];
            textBox1.Text = cm.Position.ToString();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            CurrencyManager cm =
                (CurrencyManager)this.BindingContext[listBox1.DataSource];
            textBox1.Text = cm.Position.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
