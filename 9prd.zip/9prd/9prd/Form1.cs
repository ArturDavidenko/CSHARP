﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using NpgsqlTypes;

namespace _9prd
{
    public partial class Form1 : Form
    {
        private const string ConnectionString = "Host = localhost; Username = arturs; password=12345; Database = csharp";
        private readonly NpgsqlDataAdapter _studentAdapter = new();
        private readonly NpgsqlDataAdapter _programmAdapter = new();
        private readonly NpgsqlDataAdapter _facultyAdapter = new();
        private DataSet _ds = new("University");
        DataTable dtStudents = new("Students");
        DataTable dtStProgramms = new("Programms");
        DataTable dtFaculties = new("Faculties");

        public Form1()
        {
            InitializeComponent();
            _ds.Tables.Add(dtStudents);
            _ds.Tables.Add(dtStProgramms);
            _ds.Tables.Add(dtFaculties);

            const string firstSql = "SELECT * FROM students";
            const string secondSql = "SELECT * FROM st_programm";
            const string thirdSql = "SELECT * FROM faculty";
            var connection = new NpgsqlConnection(ConnectionString);

            DataGridViewButtonColumn buttonColumn = new();
            buttonColumn.HeaderText = "Visi dati";
            buttonColumn.Name = "Dati";
            buttonColumn.Text = "Studenta uzvards";
            buttonColumn.UseColumnTextForButtonValue = true;



            try
            {
                var command1 = new NpgsqlCommand(firstSql, connection);
                _studentAdapter.SelectCommand = command1;
                _studentAdapter.Fill(dtStudents);
                dataGridView1.DataSource = dtStudents;
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.Columns[5].Visible = false;


                dataGridView1.Columns.Insert(0, buttonColumn);
                dataGridView1.CellClick += new((sender, args) =>
                {
                    if (!dataGridView1.CurrentCell.ColumnIndex.Equals(0)) return;
                    var dgView = (DataGridView)sender;
                    var cm = (CurrencyManager)BindingContext[dgView.DataSource];
                    MessageBox.Show($"Studenta uzvārds ir {dataGridView1.Rows[cm.Position].Cells[4].Value}");
                });

                var command2 = new NpgsqlCommand(secondSql, connection);
                _programmAdapter.SelectCommand = command2;
                _programmAdapter.Fill(dtStProgramms);
                dataGridView2.DataSource = dtStProgramms;
                dataGridView2.Columns[0].Visible = false;
                dataGridView2.Columns[2].Visible = false;

                var command3 = new NpgsqlCommand(thirdSql, connection);
                _facultyAdapter.SelectCommand = command3;
                _facultyAdapter.Fill(dtFaculties);
                dataGridView3.DataSource = dtFaculties;
                dataGridView3.Columns[0].Visible = false;

                _ds.Relations.Add(new DataRelation("relation",
                    _ds.Tables[2].Columns["id"],
                    _ds.Tables[1].Columns["id_faculty"], true));

                var cb = new DataGridViewComboBoxColumn
                {
                    HeaderText = "studiju_programma",
                    DataSource = _ds.Tables["Programms"],
                    DisplayMember = "title",
                    ValueMember = "id",
                    DataPropertyName = "id_sp"
                };

                var cd = new DataGridViewComboBoxColumn
                {
                    HeaderText = "fakultate",
                    DataSource = _ds.Tables["Faculties"],
                    DisplayMember = "title",
                    ValueMember = "id",
                    DataPropertyName = "id_faculty"
                };

                dataGridView1.Columns.Insert(6, cb);
                dataGridView2.Columns.Insert(2, cd);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void GetDataButton_Click(object sender, EventArgs e)
        {
            _ds.Tables[0].Clear();
            _ds.Tables[1].Clear();
            _ds.Tables[2].Clear();
            _ds.EnforceConstraints = false;

            _studentAdapter.Fill(dtStudents);
            _programmAdapter.Fill(dtStProgramms);
            _facultyAdapter.Fill(dtFaculties);
        }

        private void SaveDataButton_Click(object sender, EventArgs e)
        {
            var connection = new NpgsqlConnection(ConnectionString);

            #region students

            var studentsInsertCommand = new NpgsqlCommand("INSERT INTO students (name, surname, gender, birthdate, id_sp) VALUES (@name, @surname, @gender, @birthdate, @id_sp)", connection);
            studentsInsertCommand.Parameters.Add(new NpgsqlParameter("@name", NpgsqlDbType.Varchar, 12, "name"));
            studentsInsertCommand.Parameters.Add(new NpgsqlParameter("@surname", NpgsqlDbType.Varchar, 12, "surname"));
            studentsInsertCommand.Parameters.Add(new NpgsqlParameter("@gender", NpgsqlDbType.Varchar, 12, "gender"));
            studentsInsertCommand.Parameters.Add(new NpgsqlParameter("@birthdate", NpgsqlDbType.Date, 12, "birthdate"));
            studentsInsertCommand.Parameters.Add(new NpgsqlParameter("@id_sp", NpgsqlDbType.Integer, 12, "id_sp"));

            var studentsUpdateCommand =
                new NpgsqlCommand(
                    "UPDATE students SET name = @name, surname = @surname, gender = @gender, birthdate = @birthdate, id_sp = @id_sp WHERE id = @id",
                    connection);
            studentsUpdateCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            studentsUpdateCommand.Parameters.Add(new NpgsqlParameter("@name", NpgsqlDbType.Varchar, 12, "name"));
            studentsUpdateCommand.Parameters.Add(new NpgsqlParameter("@surname", NpgsqlDbType.Varchar, 12, "surname"));
            studentsUpdateCommand.Parameters.Add(new NpgsqlParameter("@gender", NpgsqlDbType.Varchar, 12, "gender"));
            studentsUpdateCommand.Parameters.Add(new NpgsqlParameter("@birthdate", NpgsqlDbType.Date, 12, "birthdate"));
            studentsUpdateCommand.Parameters.Add(new NpgsqlParameter("@id_sp", NpgsqlDbType.Integer, 12, "id_sp"));

            var studentsDeleteCommand = new NpgsqlCommand("DELETE FROM students WHERE id=@id", connection);
            studentsDeleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            #endregion

            #region programms

            var programmsInsertCommands = new NpgsqlCommand("INSERT INTO st_programm (title, id_faculty) VALUES (@title, @id_faculty)", connection);
            programmsInsertCommands.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));
            programmsInsertCommands.Parameters.Add(new NpgsqlParameter("@id_faculty", NpgsqlDbType.Integer, 12, "id_faculty"));

            var programmsUpdateCommand = new NpgsqlCommand("UPDATE st_programm SET title = @title, id_faculty = @id_faculty WHERE id = @id", connection);
            programmsUpdateCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            programmsUpdateCommand.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));
            programmsUpdateCommand.Parameters.Add(new NpgsqlParameter("@id_faculty", NpgsqlDbType.Integer, 12, "id_faculty"));

            var programmsDeleteCommand = new NpgsqlCommand("DELETE FROM st_programm WHERE id=@id", connection);
            programmsDeleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            #endregion

            #region faculty

            var facultyInsertCommand = new NpgsqlCommand("INSERT INTO faculty (title, abbreviation) VALUES (@title, @abbreviation)", connection);
            facultyInsertCommand.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));
            facultyInsertCommand.Parameters.Add(new NpgsqlParameter("@abbreviation", NpgsqlDbType.Varchar, 12, "abbreviation"));

            var facultyUpdateCommand = new NpgsqlCommand("UPDATE faculty SET title = @title, abbreviation = @abbreviation WHERE id = @id", connection);
            facultyUpdateCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));
            facultyUpdateCommand.Parameters.Add(new NpgsqlParameter("@title", NpgsqlDbType.Varchar, 12, "title"));
            facultyUpdateCommand.Parameters.Add(new NpgsqlParameter("@abbreviation", NpgsqlDbType.Varchar, 12, "abbreviation"));

            var facultyDeleteCommand = new NpgsqlCommand("DELETE FROM faculty WHERE id=@id", connection);
            facultyDeleteCommand.Parameters.Add(new NpgsqlParameter("@id", NpgsqlDbType.Integer, 12, "id"));

            #endregion

            _studentAdapter.InsertCommand = studentsInsertCommand;
            _studentAdapter.UpdateCommand = studentsUpdateCommand;
            _studentAdapter.DeleteCommand = studentsDeleteCommand;
            _studentAdapter.Update(dtStudents);

            _programmAdapter.InsertCommand = programmsInsertCommands;
            _programmAdapter.UpdateCommand = programmsUpdateCommand;
            _programmAdapter.DeleteCommand = programmsDeleteCommand;
            _programmAdapter.Update(dtStProgramms);

            _facultyAdapter.InsertCommand = facultyInsertCommand;
            _facultyAdapter.UpdateCommand = facultyUpdateCommand;
            _facultyAdapter.DeleteCommand = facultyDeleteCommand;
            _facultyAdapter.Update(dtFaculties);
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


    }
}
